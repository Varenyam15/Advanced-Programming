package edu.univ.erp.data;

import edu.univ.erp.domain.Grade;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class GradeRepository {

    private final Connection conn;

    public GradeRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null. Check DatabaseConfig and JDBC dependency.");
        }
        createTableIfNotExists();
    }




    public void createTableIfNotExists() {
        String sql = """
        CREATE TABLE IF NOT EXISTS grades (
          grade_id INT AUTO_INCREMENT PRIMARY KEY,
          enrollment_id INT NOT NULL,
          letter_grade VARCHAR(5),
          grade_points DOUBLE,

          FOREIGN KEY(enrollment_id) REFERENCES enrollments(enrollment_id)
        );
        """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Grades table verified/created.");
        } catch (SQLException e) {
            System.err.println("Error creating grades table: " + e.getMessage());
        }
    }




    public boolean insertGrade(Grade grade) {
        String sql = """
            INSERT INTO grades(enrollment_id, letter_grade, grade_points)
            VALUES (?, ?, ?);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, grade.getEnrollmentId());
            ps.setString(2, grade.getLetterGrade());
            ps.setDouble(3, grade.getGradePoints());

            int affected = ps.executeUpdate();
            if (affected == 0) return false;

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    grade.setGradeId(keys.getInt(1));
                }
            }
            return true;

        } catch (SQLException e) {
            System.err.println("Error inserting grade: " + e.getMessage());
            return false;
        }
    }




    public boolean updateGrade(Grade grade) {
        String sql = """
            UPDATE grades
            SET enrollment_id=?, letter_grade=?, grade_points=?
            WHERE grade_id=?;
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, grade.getEnrollmentId());
            ps.setString(2, grade.getLetterGrade());
            ps.setDouble(3, grade.getGradePoints());
            ps.setInt(4, grade.getGradeId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error updating grade: " + e.getMessage());
            return false;
        }
    }




    public boolean deleteGrade(int gradeId) {
        String sql = "DELETE FROM grades WHERE grade_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, gradeId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error deleting grade: " + e.getMessage());
            return false;
        }
    }




    public Grade getGradeById(int gradeId) {
        String sql = "SELECT * FROM grades WHERE grade_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, gradeId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Grade(
                            rs.getInt("grade_id"),
                            rs.getInt("enrollment_id"),
                            rs.getString("letter_grade"),
                            rs.getDouble("grade_points")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching grade: " + e.getMessage());
        }
        return null;
    }




    public Grade getGradeByEnrollmentId(int enrollmentId) {
        String sql = "SELECT * FROM grades WHERE enrollment_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, enrollmentId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Grade(
                            rs.getInt("grade_id"),
                            rs.getInt("enrollment_id"),
                            rs.getString("letter_grade"),
                            rs.getDouble("grade_points")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching grade by enrollment: " + e.getMessage());
        }
        return null;
    }




    public List<Grade> getAllGrades() {
        List<Grade> list = new ArrayList<>();
        String sql = "SELECT * FROM grades;";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Grade(
                        rs.getInt("grade_id"),
                        rs.getInt("enrollment_id"),
                        rs.getString("letter_grade"),
                        rs.getDouble("grade_points")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Error fetching grades: " + e.getMessage());
        }

        return list;
    }
}
