package edu.univ.erp.ui.instructor;

import edu.univ.erp.api.auth.LoginAPI;
import edu.univ.erp.auth.UserSession;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class InstructorDashboard extends JFrame {

    private final LoginAPI loginAPI;
    private final JLabel welcomeLabel;
    private final JButton mySectionsButton;
    private final JButton enterGradesButton;
    private final JButton logoutButton;

    public InstructorDashboard() {
        super("University ERP - Instructor Dashboard");

        this.loginAPI = new LoginAPI();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 250);
        setLocationRelativeTo(null);
        setResizable(false);

        if (new edu.univ.erp.service.MaintenanceService().isMaintenanceMode()) {
            JLabel banner = new JLabel("⚠️ SYSTEM IN MAINTENANCE MODE - READ ONLY ⚠️", SwingConstants.CENTER);
            banner.setOpaque(true);
            banner.setBackground(Color.RED);
            banner.setForeground(Color.WHITE);
            banner.setFont(new Font("SansSerif", Font.BOLD, 14));
            add(banner, BorderLayout.NORTH);
        }

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        String username = UserSession.getUsername();
        welcomeLabel = new JLabel("Welcome, Instructor " + (username != null ? username : ""), SwingConstants.CENTER);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(Font.BOLD, 18f));
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        mySectionsButton = new JButton("My Sections");
        enterGradesButton = new JButton("Enter Grades");
        logoutButton = new JButton("Logout");

        centerPanel.add(mySectionsButton);
        centerPanel.add(enterGradesButton);
        centerPanel.add(logoutButton);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JLabel statusLabel = new JLabel("Instructor mode", SwingConstants.CENTER);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        mySectionsButton.addActionListener(this::onMySections);
        enterGradesButton.addActionListener(this::onEnterGrades);
        logoutButton.addActionListener(this::onLogout);

        setContentPane(mainPanel);

        if (!UserSession.isLoggedIn() || !"INSTRUCTOR".equals(UserSession.getRole())) {
            JOptionPane.showMessageDialog(
                    this,
                    "Access denied: INSTRUCTOR role required.",
                    "Unauthorized",
                    JOptionPane.ERROR_MESSAGE
            );
            dispose();
        }
    }

    private void onMySections(ActionEvent e) {
        JFrame frame = new JFrame("My Sections");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(800, 400);
        frame.setLocationRelativeTo(this);
        frame.setContentPane(new MySectionsPanel());
        frame.setVisible(true);
    }

    private void onEnterGrades(ActionEvent e) {
        JFrame frame = new JFrame("Enter Grades");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(900, 400);
        frame.setLocationRelativeTo(this);
        frame.setContentPane(new GradeEntryPanel());
        frame.setVisible(true);
    }

    private void onLogout(ActionEvent e) {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION
        );
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        loginAPI.logout();
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InstructorDashboard dashboard = new InstructorDashboard();
            dashboard.setVisible(true);
        });
    }
}



