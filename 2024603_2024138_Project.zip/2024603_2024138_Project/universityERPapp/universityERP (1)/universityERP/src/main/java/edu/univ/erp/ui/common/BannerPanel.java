package edu.univ.erp.ui.common;

import javax.swing.*;
import java.awt.*;

public class BannerPanel extends JPanel {

    private final JLabel titleLabel;

    public BannerPanel(String title) {
        setLayout(new BorderLayout());
        setBackground(new Color(30, 60, 120));

        titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));

        add(titleLabel, BorderLayout.CENTER);
    }

    public void setTitle(String title) {
        titleLabel.setText(title);
    }
}
