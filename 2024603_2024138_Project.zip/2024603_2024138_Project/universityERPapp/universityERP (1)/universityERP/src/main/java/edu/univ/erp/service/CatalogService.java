package edu.univ.erp.service;

import edu.univ.erp.data.CourseRepository;
import edu.univ.erp.data.SectionRepository;
import edu.univ.erp.data.InstructorRepository;

import edu.univ.erp.domain.Course;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Instructor;

import java.util.List;


public class CatalogService {

    private final CourseRepository courseRepo;
    private final SectionRepository sectionRepo;
    private final InstructorRepository instructorRepo;




    public CatalogService() {
        this.courseRepo = new CourseRepository();
        this.sectionRepo = new SectionRepository();
        this.instructorRepo = new InstructorRepository();
    }





    public List<Course> getAllCourses() {
        return courseRepo.getAllCourses();
    }

    public Course getCourseById(String courseId) {
        return courseRepo.getCourseById(courseId);
    }

    public List<Course> searchCoursesByName(String name) {
        return courseRepo.getAllCourses()
                .stream()
                .filter(c -> c.getCourseName().toLowerCase().contains(name.toLowerCase()))
                .toList();
    }

    public List<Course> searchCoursesByDepartment(String department) {
        return courseRepo.getAllCourses()
                .stream()
                .filter(c -> c.getDepartment() != null &&
                        c.getDepartment().equalsIgnoreCase(department))
                .toList();
    }





    public List<Section> getAllSections() {
        return sectionRepo.getAllSections();
    }

    public List<Section> getSectionsForCourse(String courseId) {
        return sectionRepo.getAllSections()
                .stream()
                .filter(s -> s.getCourseId().equalsIgnoreCase(courseId))
                .toList();
    }

    public Section getSectionById(int sectionId) {
        return sectionRepo.getSectionById(sectionId);
    }





    public Instructor getInstructorById(int instructorId) {
        return instructorRepo.getInstructorById(instructorId);
    }






    public String getFullSectionDisplayInfo(Section section) {
        Course course = courseRepo.getCourseById(section.getCourseId());
        Instructor instructor = instructorRepo.getInstructorById(section.getInstructorId());

        return String.format(
                "%s (%s) | Section %d | %s | Instructor: %s %s | Room: %s | Seats: %d",
                course.getCourseName(),
                course.getCourseId(),
                section.getSectionId(),
                section.getSchedule(),
                instructor.getFirstName(),
                instructor.getLastName(),
                section.getRoom(),
                section.getCapacity()
        );
    }
}
