package edu.univ.erp.auth.model;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.AuthRepository;


public class AdminReset {
    public static void main(String[] args) {
        System.out.println("--- STARTING ADMIN RESET ---");


        AuthService authService = new AuthService();
        AuthRepository repo = new AuthRepository();


        System.out.println("Deleting existing 'admin' user...");
        try {

            repo.deleteUser(repo.getUserByUsername("admin").getUserId());
        } catch (Exception e) {
            System.out.println("User 'admin' did not exist (that is fine).");
        }


        System.out.println("Creating new Admin user...");

        boolean success = authService.registerUser("admin", "admin", "ADMIN");

        if (success) {
            System.out.println("SUCCESS! User 'admin' created.");
            System.out.println("You can now launch LoginWindow and log in with:");
            System.out.println("User: admin");
            System.out.println("Pass: admin");
        } else {
            System.err.println("FAILED. Could not create user. Check DB connection.");
        }
    }
}