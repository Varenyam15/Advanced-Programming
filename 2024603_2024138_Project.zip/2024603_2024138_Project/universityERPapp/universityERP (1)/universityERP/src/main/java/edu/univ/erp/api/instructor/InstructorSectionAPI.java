package edu.univ.erp.api.instructor;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Student;
import edu.univ.erp.service.InstructorService;

import java.util.List;


public class InstructorSectionAPI {

    private final InstructorService instructorService;

    public InstructorSectionAPI() {
        this.instructorService = new InstructorService();
    }

    private void requireInstructor() {
        if (!UserSession.isLoggedIn() || !"INSTRUCTOR".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: INSTRUCTOR role required.");
        }
    }

    public List<Section> getMySections() {
        requireInstructor();
        int instructorId = UserSession.getUserId();
        return instructorService.getSectionsTaught(instructorId);
    }

    public List<Student> getStudentsInSection(int sectionId) {
        requireInstructor();
        return instructorService.getStudentsInSection(sectionId);
    }


    public Section getMySectionById(int sectionId) {
        requireInstructor();
        int instructorId = UserSession.getUserId();
        return getMySections().stream()
                .filter(s -> s.getSectionId() == sectionId && s.getInstructorId() == instructorId)
                .findFirst()
                .orElse(null);
    }
}

