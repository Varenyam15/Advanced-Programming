package edu.univ.erp.ui.instructor;

import edu.univ.erp.api.instructor.InstructorSectionAPI;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MySectionsPanel extends JPanel {

    private final InstructorSectionAPI sectionAPI;

    private final JTable sectionsTable;
    private final DefaultTableModel sectionsModel;

    private final JTable studentsTable;
    private final DefaultTableModel studentsModel;

    private final JButton loadSectionsButton;
    private final JButton loadStudentsButton;

    public MySectionsPanel() {
        this.sectionAPI = new InstructorSectionAPI();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("My Sections", SwingConstants.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 18f));
        add(titleLabel, BorderLayout.NORTH);

        String[] sectionCols = { "Section ID", "Course ID", "Semester", "Schedule", "Room", "Capacity" };
        sectionsModel = new DefaultTableModel(sectionCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        sectionsTable = new JTable(sectionsModel);
        JScrollPane sectionsScroll = new JScrollPane(sectionsTable);

        String[] studentCols = { "Student ID", "First Name", "Last Name", "Email" };
        studentsModel = new DefaultTableModel(studentCols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        studentsTable = new JTable(studentsModel);
        JScrollPane studentsScroll = new JScrollPane(studentsTable);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, sectionsScroll, studentsScroll);
        splitPane.setResizeWeight(0.5);
        add(splitPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        loadSectionsButton = new JButton("Load My Sections");
        loadStudentsButton = new JButton("Load Students for Selected Section");
        bottomPanel.add(loadSectionsButton);
        bottomPanel.add(loadStudentsButton);
        add(bottomPanel, BorderLayout.SOUTH);

        loadSectionsButton.addActionListener(e -> loadSections());
        loadStudentsButton.addActionListener(e -> loadStudentsForSelectedSection());

        loadSections();
    }

    private void loadSections() {
        sectionsModel.setRowCount(0);
        List<Section> sections = sectionAPI.getMySections();
        if (sections == null) {
            return;
        }
        for (Section s : sections) {
            sectionsModel.addRow(new Object[] {
                    s.getSectionId(),
                    s.getCourseId(),
                    s.getSemester(),
                    s.getSchedule(),
                    s.getRoom(),
                    s.getCapacity()
            });
        }
    }

    private Integer getSelectedSectionId() {
        int row = sectionsTable.getSelectedRow();
        if (row < 0) {
            return null;
        }
        Object value = sectionsModel.getValueAt(row, 0);
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(String.valueOf(value));
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private void loadStudentsForSelectedSection() {
        Integer sectionId = getSelectedSectionId();
        if (sectionId == null) {
            JOptionPane.showMessageDialog(this, "Please select a section.", "No Section Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        studentsModel.setRowCount(0);
        List<Student> students = sectionAPI.getStudentsInSection(sectionId);
        if (students == null) {
            return;
        }
        for (Student st : students) {
            studentsModel.addRow(new Object[] {
                    st.getStudentId(),
                    st.getFirstName(),
                    st.getLastName(),
                    st.getEmail()
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("My Sections Panel (Test)");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900, 500);
            frame.setLocationRelativeTo(null);
            frame.setContentPane(new MySectionsPanel());
            frame.setVisible(true);
        });
    }
}
