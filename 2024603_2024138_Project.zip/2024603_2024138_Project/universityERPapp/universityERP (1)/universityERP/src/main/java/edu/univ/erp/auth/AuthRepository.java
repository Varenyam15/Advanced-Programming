package edu.univ.erp.auth;

import edu.univ.erp.auth.model.AuthUser;
import edu.univ.erp.data.DatabaseConfig;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class AuthRepository {

    private final Connection conn;




    public AuthRepository() {
        this.conn = DatabaseConfig.getAuthConnection();
        createTableIfNotExists();
    }




    private void createTableIfNotExists() {
        if (conn == null) {
            throw new IllegalStateException("Auth DB connection is null.");
        }

        String sql = """
    CREATE TABLE IF NOT EXISTS auth_users (
        id INT AUTO_INCREMENT,
        username VARCHAR(100) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        salt VARCHAR(50) NOT NULL,
        PRIMARY KEY (id)
    );
""";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error creating auth_users table: " + e.getMessage());
            e.printStackTrace();
        }
    }




    public boolean insertUser(AuthUser user) {
        String sql = "INSERT INTO auth_users (username, password_hash, role, salt) VALUES (?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPasswordHash());
            pstmt.setString(3, user.getRole());
            pstmt.setString(4, user.getSalt());

            int rows = pstmt.executeUpdate();

            if (rows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        user.setUserId(rs.getInt(1));
                    }
                }
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Error inserting auth user: " + e.getMessage());
        }

        return false;
    }




    public AuthUser getUserByUsername(String username) {
        String sql = "SELECT id, username, password_hash, role, salt FROM auth_users WHERE username = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new AuthUser(
                            rs.getInt("id"),
                            rs.getString("username"),
                            rs.getString("password_hash"),
                            rs.getString("role"),
                            rs.getString("salt")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching user by username: " + e.getMessage());
        }

        return null;
    }




    public AuthUser getUserById(int userId) {
        String sql = "SELECT * FROM auth_users WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new AuthUser(
                            rs.getInt("id"),
                            rs.getString("username"),
                            rs.getString("password_hash"),
                            rs.getString("role"),
                            rs.getString("salt")
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching user by ID: " + e.getMessage());
        }

        return null;
    }




    public List<AuthUser> getAllUsers() {
        List<AuthUser> users = new ArrayList<>();
        String sql = "SELECT * FROM auth_users";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                users.add(new AuthUser(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password_hash"),
                        rs.getString("role"),
                        rs.getString("salt")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Error fetching all users: " + e.getMessage());
        }

        return users;
    }




    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM auth_users WHERE id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error deleting auth user: " + e.getMessage());
        }

        return false;
    }
    public boolean updatePassword(String username, String newHash, String newSalt) {
        String sql = "UPDATE auth_users SET password_hash = ?, salt = ? WHERE username = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newHash);
            pstmt.setString(2, newSalt);
            pstmt.setString(3, username);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
