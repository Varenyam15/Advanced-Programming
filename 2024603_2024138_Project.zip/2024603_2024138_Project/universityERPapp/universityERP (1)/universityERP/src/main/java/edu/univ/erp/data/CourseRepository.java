package edu.univ.erp.data;

import edu.univ.erp.domain.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class CourseRepository {

    private final Connection conn;

    public CourseRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null. Check DatabaseConfig and JDBC dependency.");
        }
        createTableIfNotExists();
    }

    public void createTableIfNotExists() {
        String sql = """
        CREATE TABLE IF NOT EXISTS courses (
          course_id VARCHAR(50) PRIMARY KEY,
          course_name VARCHAR(255) NOT NULL,
          department VARCHAR(100),
          credits INT
        );
        """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Courses table verified/created.");
        } catch (SQLException e) {
            System.err.println("Error creating courses table: " + e.getMessage());
        }
    }

    public boolean insertCourse(Course course) {
        String sql = """
            INSERT INTO courses(course_id, course_name, department, credits)
            VALUES (?, ?, ?, ?);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, course.getCourseId());
            ps.setString(2, course.getCourseName());
            ps.setString(3, course.getDepartment());
            ps.setInt(4, course.getCredits());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error inserting course: " + e.getMessage());
            return false;
        }
    }

    public boolean updateCourse(Course course) {
        String sql = """
            UPDATE courses
            SET course_name=?, department=?, credits=?
            WHERE course_id=?;
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, course.getCourseName());
            ps.setString(2, course.getDepartment());
            ps.setInt(3, course.getCredits());
            ps.setString(4, course.getCourseId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error updating course: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteCourse(String courseId) {
        String sql = "DELETE FROM courses WHERE course_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, courseId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting course: " + e.getMessage());
            return false;
        }
    }

    public Course getCourseById(String courseId) {
        String sql = "SELECT * FROM courses WHERE course_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Course(
                            rs.getString("course_id"),
                            rs.getString("course_name"),
                            rs.getString("department"),
                            rs.getInt("credits")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching course: " + e.getMessage());
        }
        return null;
    }

    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM courses;";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                courses.add(new Course(
                        rs.getString("course_id"),
                        rs.getString("course_name"),
                        rs.getString("department"),
                        rs.getInt("credits")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Error fetching courses: " + e.getMessage());
        }

        return courses;
    }
}

