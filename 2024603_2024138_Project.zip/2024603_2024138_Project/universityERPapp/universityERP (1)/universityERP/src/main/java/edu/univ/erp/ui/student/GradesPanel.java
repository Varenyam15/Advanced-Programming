package edu.univ.erp.ui.student;

import edu.univ.erp.api.student.StudentTranscriptAPI;
import edu.univ.erp.domain.Grade;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GradesPanel extends JPanel {

    private final StudentTranscriptAPI transcriptAPI;

    private final JTable gradesTable;
    private final DefaultTableModel tableModel;

    private final JButton refreshButton;
    private final JLabel gpaLabel;

    public GradesPanel() {
        this.transcriptAPI = new StudentTranscriptAPI();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("My Grades", SwingConstants.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 18f));
        add(titleLabel, BorderLayout.NORTH);

        String[] cols = { "Enrollment ID", "Letter Grade", "Grade Points" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        gradesTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(gradesTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        gpaLabel = new JLabel("GPA: N/A");
        gpaLabel.setHorizontalAlignment(SwingConstants.LEFT);
        refreshButton = new JButton("Refresh");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(refreshButton);
        bottomPanel.add(gpaLabel, BorderLayout.WEST);
        bottomPanel.add(buttonPanel, BorderLayout.EAST);

        add(bottomPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> loadGrades());

        loadGrades();
    }

    private void loadGrades() {
        tableModel.setRowCount(0);
        List<Grade> grades = transcriptAPI.getMyGrades();
        if (grades != null) {
            for (Grade g : grades) {
                tableModel.addRow(new Object[] {
                        g.getEnrollmentId(),
                        g.getLetterGrade(),
                        g.getGradePoints()
                });
            }
        }
        Double gpa = transcriptAPI.getMyGpa();
        if (gpa != null) {
            gpaLabel.setText("GPA: " + String.format("%.2f", gpa));
        } else {
            gpaLabel.setText("GPA: N/A");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Grades Panel (Test)");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setSize(900, 500);
            f.setLocationRelativeTo(null);
            f.setContentPane(new GradesPanel());
            f.setVisible(true);
        });
    }
}
