package edu.univ.erp.ui.admin;

import edu.univ.erp.service.MaintenanceService;

import javax.swing.*;
import java.awt.*;

public class MaintenancePanel extends JPanel {

    private final MaintenanceService maintenanceService;
    private final JLabel statusLabel;
    private final JButton toggleButton;
    private final JButton rebuildButton;
    private final JButton openRegButton;
    private final JButton closeRegButton;

    public MaintenancePanel() {
        this.maintenanceService = new MaintenanceService();

        setLayout(new BorderLayout(20, 20));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel title = new JLabel("System Maintenance", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(title, BorderLayout.NORTH);

        // Center Panel (Controls)
        JPanel centerPanel = new JPanel(new GridLayout(4, 1, 10, 10));

        // 1. Maintenance Mode Toggle
        JPanel maintPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        maintPanel.setBorder(BorderFactory.createTitledBorder("Global Maintenance Mode"));

        statusLabel = new JLabel("Status: UNKNOWN");
        statusLabel.setFont(new Font("SansSerif", Font.BOLD, 14));

        toggleButton = new JButton("Toggle Mode");
        toggleButton.addActionListener(e -> onToggleMaintenance());

        maintPanel.add(statusLabel);
        maintPanel.add(Box.createHorizontalStrut(20));
        maintPanel.add(toggleButton);

        centerPanel.add(maintPanel);

        // 2. Registration Controls
        JPanel regPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        regPanel.setBorder(BorderFactory.createTitledBorder("Registration Period"));
        openRegButton = new JButton("Open Registration");
        closeRegButton = new JButton("Close Registration");

        openRegButton.addActionListener(e -> {
            maintenanceService.openRegistration();
            JOptionPane.showMessageDialog(this, "Registration OPENED.");
        });
        closeRegButton.addActionListener(e -> {
            maintenanceService.closeRegistration();
            JOptionPane.showMessageDialog(this, "Registration CLOSED.");
        });

        regPanel.add(openRegButton);
        regPanel.add(closeRegButton);
        centerPanel.add(regPanel);

        // 3. Dangerous Actions
        JPanel dangerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        dangerPanel.setBorder(BorderFactory.createTitledBorder("Dangerous Actions"));
        rebuildButton = new JButton("Rebuild Database (Reset All)");
        rebuildButton.setForeground(Color.RED);
        rebuildButton.addActionListener(e -> onRebuild());
        dangerPanel.add(rebuildButton);

        centerPanel.add(dangerPanel);

        add(centerPanel, BorderLayout.CENTER);

        // Initial Status Check
        updateStatusLabel();
    }

    private void onToggleMaintenance() {
        boolean current = maintenanceService.isMaintenanceMode();
        boolean newState = !current;

        boolean success = maintenanceService.setMaintenanceMode(newState);
        if (success) {
            updateStatusLabel();
            String msg = newState ? "Maintenance Mode ON.\nStudents/Instructors cannot make changes."
                    : "Maintenance Mode OFF.\nSystem is normal.";
            JOptionPane.showMessageDialog(this, msg);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update settings.");
        }
    }

    private void updateStatusLabel() {
        boolean isOn = maintenanceService.isMaintenanceMode();
        if (isOn) {
            statusLabel.setText("Status: ON (Locked)");
            statusLabel.setForeground(Color.RED);
            toggleButton.setText("Turn OFF");
        } else {
            statusLabel.setText("Status: OFF (Normal)");
            statusLabel.setForeground(new Color(0, 128, 0));
            toggleButton.setText("Turn ON");
        }
    }

    private void onRebuild() {
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure? This deletes ALL data.", "Confirm Rebuild", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            boolean ok = maintenanceService.rebuildDatabase();
            JOptionPane.showMessageDialog(this, ok ? "Database Rebuilt." : "Error rebuilding DB.");
        }
    }
}