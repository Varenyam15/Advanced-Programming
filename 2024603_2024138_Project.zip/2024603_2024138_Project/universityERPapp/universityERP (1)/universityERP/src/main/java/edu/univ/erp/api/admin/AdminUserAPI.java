package edu.univ.erp.api.admin;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.UserSession;


public class AdminUserAPI {

    private final AuthService authService;

    public AdminUserAPI() {
        this.authService = new AuthService();
    }

    private void requireAdmin() {
        if (!UserSession.isLoggedIn() || !"ADMIN".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: ADMIN role required.");
        }
    }

    public boolean createUser(String username, String password, String role) {
        requireAdmin();
        return authService.registerUser(username, password, role);
    }

    public boolean updatePassword(String username, String newPassword) {
        requireAdmin();
        return authService.updatePassword(username, newPassword);
    }

    public boolean deleteUser(String username) {
        requireAdmin();
        return authService.deleteUser(username);
    }

    public boolean userExists(String username) {
        requireAdmin();
        return authService.userExists(username);
    }
}


