package edu.univ.erp.api.auth;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.UserSession;
import edu.univ.erp.auth.model.AuthUser;

public class ChangePasswordAPI {
    private final AuthService authService;

    public ChangePasswordAPI() {
        this.authService = new AuthService();
    }

    public boolean changeMyPassword(String oldPassword, String newPassword) {
        if (!UserSession.isLoggedIn()) {
            throw new SecurityException("You must be logged in to change your password.");
        }

        String username = UserSession.getUsername();
        AuthUser user = authService.login(username, oldPassword);
        if (user == null) {
            return false;
        }

        return authService.updatePassword(username, newPassword);
    }

    public boolean changePassword(String username, String oldPassword, String newPassword) {
        return changeMyPassword(oldPassword, newPassword);
    }
}

