package edu.univ.erp.util;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CSVExporter {

    public static boolean exportTable(JTable table, String defaultFileName) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save as CSV");
        fileChooser.setSelectedFile(new File(defaultFileName));

        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            // Ensure extension is .csv
            if (!fileToSave.getAbsolutePath().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".csv");
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileToSave))) {
                TableModel model = table.getModel();

                // 1. Write Column Headers
                for (int i = 0; i < model.getColumnCount(); i++) {
                    bw.write(model.getColumnName(i));
                    if (i < model.getColumnCount() - 1) bw.write(",");
                }
                bw.newLine();

                // 2. Write Data Rows
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        Object value = model.getValueAt(i, j);
                        String str = (value == null) ? "" : value.toString();

                        // Escape commas/quotes for CSV safety
                        if (str.contains(",") || str.contains("\"")) {
                            str = "\"" + str.replace("\"", "\"\"") + "\"";
                        }

                        bw.write(str);
                        if (j < model.getColumnCount() - 1) bw.write(",");
                    }
                    bw.newLine();
                }
                return true; // Success

            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving file: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return false; // User cancelled or error
    }
}