package edu.univ.erp.ui.auth;

import edu.univ.erp.api.auth.ChangePasswordAPI;
import edu.univ.erp.auth.UserSession;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ChangePasswordDialog extends JDialog {

    private final ChangePasswordAPI changePasswordAPI;

    private final JPasswordField oldPasswordField;
    private final JPasswordField newPasswordField;
    private final JPasswordField confirmPasswordField;

    private final JButton saveButton;
    private final JButton cancelButton;

    public ChangePasswordDialog(Frame parent) {
        super(parent, "Change Password", true);

        this.changePasswordAPI = new ChangePasswordAPI();

        setSize(400, 250);
        setLocationRelativeTo(parent);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel oldPassLabel = new JLabel("Old Password:");
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(oldPassLabel, gbc);

        oldPasswordField = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(oldPasswordField, gbc);

        JLabel newPassLabel = new JLabel("New Password:");
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(newPassLabel, gbc);

        newPasswordField = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(newPasswordField, gbc);

        JLabel confirmPassLabel = new JLabel("Confirm Password:");
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(confirmPassLabel, gbc);

        confirmPasswordField = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(confirmPasswordField, gbc);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");
        btnPanel.add(saveButton);
        btnPanel.add(cancelButton);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(btnPanel, gbc);

        add(panel);

        saveButton.addActionListener(this::onSave);
        cancelButton.addActionListener(e -> dispose());
    }

    private void onSave(ActionEvent e) {
        String oldPass = new String(oldPasswordField.getPassword()).trim();
        String newPass = new String(newPasswordField.getPassword()).trim();
        String confirm = new String(confirmPasswordField.getPassword()).trim();

        if (oldPass.isEmpty() || newPass.isEmpty() || confirm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill all fields.");
            return;
        }

        if (!newPass.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "New passwords do not match.");
            return;
        }

        boolean ok = changePasswordAPI.changePassword(UserSession.getUsername(), oldPass, newPass);
        JOptionPane.showMessageDialog(this, ok ? "Password changed." : "Password change failed.");
        if (ok) {
            dispose();
        }
    }
}
