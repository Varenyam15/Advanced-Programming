package edu.univ.erp.service;

import edu.univ.erp.data.*;
import edu.univ.erp.domain.Setting;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class MaintenanceService {

    private final SettingsRepository settingsRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final GradeRepository gradeRepo;
    private final SectionRepository sectionRepo;


    private final StudentRepository studentRepo;
    private final InstructorRepository instructorRepo;
    private final CourseRepository courseRepo;

    public MaintenanceService() {
        this.settingsRepo = new SettingsRepository();
        this.enrollmentRepo = new EnrollmentRepository();
        this.gradeRepo = new GradeRepository();
        this.sectionRepo = new SectionRepository();


        this.studentRepo = new StudentRepository();
        this.instructorRepo = new InstructorRepository();
        this.courseRepo = new CourseRepository();
    }

    public boolean rebuildDatabase() {
        Connection conn = DatabaseConfig.getErpConnection();
        if (conn == null) {
            System.err.println("ERP DB connection is null — cannot rebuild database.");
            return false;
        }

        try (Statement stmt = conn.createStatement()) {

            stmt.execute("SET FOREIGN_KEY_CHECKS = 0;");


            stmt.execute("DROP TABLE IF EXISTS grades;");
            stmt.execute("DROP TABLE IF EXISTS enrollments;");
            stmt.execute("DROP TABLE IF EXISTS sections;");
            stmt.execute("DROP TABLE IF EXISTS courses;");
            stmt.execute("DROP TABLE IF EXISTS instructors;");
            stmt.execute("DROP TABLE IF EXISTS students;");
            stmt.execute("DROP TABLE IF EXISTS settings;");


            stmt.execute("SET FOREIGN_KEY_CHECKS = 1;");

            settingsRepo.createTableIfNotExists();
            studentRepo.createTableIfNotExists();
            instructorRepo.createTableIfNotExists();
            courseRepo.createTableIfNotExists();
            sectionRepo.createTableIfNotExists();
            enrollmentRepo.createTableIfNotExists();
            gradeRepo.createTableIfNotExists();

            System.out.println("Database rebuild and schema recreation completed.");
            return true;

        } catch (SQLException e) {
            System.err.println("Error rebuilding database: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean resetSemesterData() {
        Connection conn = DatabaseConfig.getErpConnection();
        if (conn == null) {
            System.err.println("ERP DB connection is null — cannot reset semester data.");
            return false;
        }

        try (Statement stmt = conn.createStatement()) {

            stmt.execute("DELETE FROM grades;");
            stmt.execute("DELETE FROM enrollments;");
            System.out.println("Semester data reset: enrollments and grades cleared.");
            return true;

        } catch (SQLException e) {
            System.err.println("Error resetting semester data: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean initializeNewSemester(String semesterName) {

        boolean ok1 = settingsRepo.saveOrUpdateSetting(new Setting("CURRENT_SEMESTER", semesterName));
        boolean ok2 = settingsRepo.saveOrUpdateSetting(new Setting("REGISTRATION_STATUS", "CLOSED"));
        return ok1 && ok2;
    }

    public boolean openRegistration() {
        return settingsRepo.saveOrUpdateSetting(new Setting("REGISTRATION_STATUS", "OPEN"));
    }

    public boolean closeRegistration() {
        return settingsRepo.saveOrUpdateSetting(new Setting("REGISTRATION_STATUS", "CLOSED"));
    }

    public boolean setMaintenanceMode(boolean enable) {
        String value = enable ? "TRUE" : "FALSE";
        return settingsRepo.saveOrUpdateSetting(new Setting("MAINTENANCE_MODE", value));
    }

    public boolean isMaintenanceMode() {
        Setting s = settingsRepo.getSetting("MAINTENANCE_MODE");
        return s != null && "TRUE".equalsIgnoreCase(s.getSettingValue());
    }

    public boolean clearAllSettings() {
        Connection conn = DatabaseConfig.getErpConnection();
        if (conn == null) {
            return false;
        }
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM settings;");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isSystemHealthy() {
        try {
            return DatabaseConfig.getErpConnection() != null;
        } catch (Exception e) {
            return false;
        }
    }
}