package edu.univ.erp.service;

import edu.univ.erp.data.*;
import edu.univ.erp.domain.*;

import java.util.List;
import java.util.stream.Collectors;


public class InstructorService {

    private final InstructorRepository instructorRepo;
    private final SectionRepository sectionRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final StudentRepository studentRepo;
    private final GradeRepository gradeRepo;
    private final MaintenanceService maintenanceService;




    public InstructorService() {
        this.instructorRepo = new InstructorRepository();
        this.sectionRepo = new SectionRepository();
        this.enrollmentRepo = new EnrollmentRepository();
        this.studentRepo = new StudentRepository();
        this.gradeRepo = new GradeRepository();
        this.maintenanceService = new MaintenanceService();
    }





    public Instructor getInstructorById(int instructorId) {
        return instructorRepo.getInstructorById(instructorId);
    }

    public boolean updateInstructorProfile(Instructor instructor) {
        return instructorRepo.updateInstructor(instructor);
    }






    public List<Section> getSectionsTaught(int instructorId) {
        return sectionRepo.getAllSections()
                .stream()
                .filter(s -> s.getInstructorId() == instructorId)
                .collect(Collectors.toList());
    }






    public List<Enrollment> getEnrollmentsForSection(int sectionId) {
        return enrollmentRepo.getEnrollmentsBySection(sectionId);
    }


    public List<Student> getStudentsInSection(int sectionId) {
        return getEnrollmentsForSection(sectionId)
                .stream()
                .map(e -> studentRepo.getStudentById(e.getStudentId()))
                .collect(Collectors.toList());
    }






    public boolean assignOrUpdateGrade(int enrollmentId, String letterGrade, double gradePoints) {
        if (maintenanceService.isMaintenanceMode()) {
            System.out.println("Blocked: Maintenance Mode is ON");
            return false;
        }
        Grade existing = gradeRepo.getGradeByEnrollmentId(enrollmentId);

        if (existing == null) {
            Grade newGrade = new Grade(0, enrollmentId, letterGrade, gradePoints);
            return gradeRepo.insertGrade(newGrade);
        } else {
            existing.setLetterGrade(letterGrade);
            existing.setGradePoints(gradePoints);
            return gradeRepo.updateGrade(existing);
        }
    }


    public List<Grade> getGradesForSection(int sectionId) {
        return enrollmentRepo.getEnrollmentsBySection(sectionId)
                .stream()
                .map(e -> gradeRepo.getGradeByEnrollmentId(e.getEnrollmentId()))
                .filter(g -> g != null)
                .collect(Collectors.toList());
    }






    public String getStudentLineForSection(int sectionId, Enrollment enrollment) {
        Student s = studentRepo.getStudentById(enrollment.getStudentId());
        Grade g = gradeRepo.getGradeByEnrollmentId(enrollment.getEnrollmentId());

        return String.format(
                "%s %s (ID: %d) | Status: %s | Grade: %s",
                s.getFirstName(),
                s.getLastName(),
                s.getStudentId(),
                enrollment.getStatus(),
                (g == null ? "Not Assigned" : g.getLetterGrade())
        );
    }
}
