package edu.univ.erp.domain;


public class Course {

    private String courseId;
    private String courseName;
    private String department;
    private int credits;





    public Course() {

    }

    public Course(String courseId, String courseName,
                  String department, int credits) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.department = department;
        this.credits = credits;
    }





    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }





    @Override
    public String toString() {
        return "Course {" +
                "courseId='" + courseId + '\'' +
                ", courseName='" + courseName + '\'' +
                ", department='" + department + '\'' +
                ", credits=" + credits +
                '}';
    }
}
