package edu.univ.erp.ui.admin;

import edu.univ.erp.api.auth.LoginAPI;
import edu.univ.erp.auth.UserSession;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;


public class AdminDashboard extends JFrame {

    private final JButton manageCoursesButton;
    private final JButton manageSectionsButton;
    private final JButton manageUsersButton;
    private final JButton maintenanceButton;
    private final JButton logoutButton;
    private final JLabel welcomeLabel;
    private final LoginAPI loginAPI;

    public AdminDashboard() {
        super("University ERP - Admin Dashboard");

        this.loginAPI = new LoginAPI();


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);
        setResizable(false);


        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));


        String username = UserSession.getUsername();
        welcomeLabel = new JLabel("Welcome, Admin " + (username != null ? username : ""), SwingConstants.CENTER);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(Font.BOLD, 18f));
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);


        JPanel centerPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        manageCoursesButton = new JButton("Manage Courses");
        manageSectionsButton = new JButton("Manage Sections");
        manageUsersButton = new JButton("Manage Users");
        maintenanceButton = new JButton("Maintenance");
        logoutButton = new JButton("Logout");

        centerPanel.add(manageCoursesButton);
        centerPanel.add(manageSectionsButton);
        centerPanel.add(manageUsersButton);
        centerPanel.add(maintenanceButton);
        centerPanel.add(logoutButton);

        mainPanel.add(centerPanel, BorderLayout.CENTER);


        JLabel statusLabel = new JLabel("Admin privileges active", SwingConstants.CENTER);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);


        manageCoursesButton.addActionListener(this::onManageCourses);
        manageSectionsButton.addActionListener(this::onManageSections);
        manageUsersButton.addActionListener(this::onManageUsers);
        maintenanceButton.addActionListener(this::onMaintenance);
        logoutButton.addActionListener(this::onLogout);

        setContentPane(mainPanel);


        if (!UserSession.isLoggedIn() || !"ADMIN".equals(UserSession.getRole())) {
            JOptionPane.showMessageDialog(
                    this,
                    "Access denied: ADMIN role required.",
                    "Unauthorized",
                    JOptionPane.ERROR_MESSAGE
            );
            dispose();
        }
    }





    private void onManageCourses(ActionEvent e) {
        JFrame frame = new JFrame("Course Management");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(new CourseManagementPanel());
        frame.pack();
        frame.setLocationRelativeTo(this);
        frame.setMinimumSize(new Dimension(800, 500));
        frame.setVisible(true);
    }

    private void onManageSections(ActionEvent e) {
        JFrame frame = new JFrame("Section Management");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(new SectionManagementPanel());
        frame.pack();
        frame.setLocationRelativeTo(this);
        frame.setVisible(true);
    }

    private void onManageUsers(ActionEvent e) {
        JFrame frame = new JFrame("User Management");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(new UserManagementPanel());
        frame.pack();
        frame.setLocationRelativeTo(this);
        frame.setMinimumSize(new Dimension(500, 450));
        frame.setVisible(true);
    }

    private void onMaintenance(ActionEvent e) {
        JFrame frame = new JFrame("Maintenance & DB Utilities");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(new MaintenancePanel());
        frame.pack();
        frame.setLocationRelativeTo(this);
        frame.setVisible(true);
    }

    private void onLogout(ActionEvent e) {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.YES_OPTION) {
            loginAPI.logout();
            dispose();



        }
    }




    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {


            AdminDashboard dashboard = new AdminDashboard();
            dashboard.setVisible(true);
        });
    }
}
