package edu.univ.erp.api.auth;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.UserSession;
import edu.univ.erp.auth.model.AuthUser;


public class LoginAPI {

    private final AuthService authService;

    public LoginAPI() {
        this.authService = new AuthService();
    }

    public boolean login(String username, String password) {
        AuthUser user = authService.login(username, password);
        if (user == null) {
            return false;
        }
        UserSession.startSession(user);
        return true;
    }

    public void logout() {
        UserSession.endSession();
    }

    public boolean isLoggedIn() {
        return UserSession.isLoggedIn();
    }
}


