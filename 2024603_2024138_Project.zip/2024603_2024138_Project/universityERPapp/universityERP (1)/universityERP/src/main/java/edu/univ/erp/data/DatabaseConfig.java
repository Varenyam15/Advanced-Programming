package edu.univ.erp.data;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConfig {

    private static final String DEFAULT_AUTH_URL = "jdbc:mysql://localhost:3306/auth_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_AUTH_USER = "root";
    private static final String DEFAULT_AUTH_PASSWORD = "qwerty2348324@8324";

    private static final String DEFAULT_ERP_URL = "jdbc:mysql://localhost:3306/erp_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_ERP_USER = "root";
    private static final String DEFAULT_ERP_PASSWORD = "qwerty2348324@8324";

    private static String authUrl = DEFAULT_AUTH_URL;
    private static String authUser = DEFAULT_AUTH_USER;
    private static String authPassword = DEFAULT_AUTH_PASSWORD;

    private static String erpUrl = DEFAULT_ERP_URL;
    private static String erpUser = DEFAULT_ERP_USER;
    private static String erpPassword = DEFAULT_ERP_PASSWORD;

    private static Connection authConnection;
    private static Connection erpConnection;

    static {
        loadProperties();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void loadProperties() {
        try (InputStream in = DatabaseConfig.class.getResourceAsStream("/config.properties")) {
            if (in == null) {
                return;
            }
            Properties props = new Properties();
            props.load(in);

            String aUrl = props.getProperty("auth.url");
            String aUser = props.getProperty("auth.user");
            String aPass = props.getProperty("auth.password");

            String eUrl = props.getProperty("erp.url");
            String eUser = props.getProperty("erp.user");
            String ePass = props.getProperty("erp.password");

            if (aUrl != null && !aUrl.isEmpty()) {
                authUrl = aUrl;
            }
            if (aUser != null && !aUser.isEmpty()) {
                authUser = aUser;
            }
            if (aPass != null) {
                authPassword = aPass;
            }

            if (eUrl != null && !eUrl.isEmpty()) {
                erpUrl = eUrl;
            }
            if (eUser != null && !eUser.isEmpty()) {
                erpUser = eUser;
            }
            if (ePass != null) {
                erpPassword = ePass;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getAuthConnection() {
        try {
            if (authConnection == null || authConnection.isClosed()) {
                authConnection = DriverManager.getConnection(authUrl, authUser, authPassword);
            }
            return authConnection;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Connection getErpConnection() {
        try {
            if (erpConnection == null || erpConnection.isClosed()) {
                erpConnection = DriverManager.getConnection(erpUrl, erpUser, erpPassword);
            }
            return erpConnection;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
