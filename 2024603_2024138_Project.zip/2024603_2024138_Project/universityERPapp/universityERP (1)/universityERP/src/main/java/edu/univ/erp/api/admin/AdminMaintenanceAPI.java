package edu.univ.erp.api.admin;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.service.MaintenanceService;


public class AdminMaintenanceAPI {

    private final MaintenanceService maintenanceService;

    public AdminMaintenanceAPI() {
        this.maintenanceService = new MaintenanceService();
    }

    private void requireAdmin() {
        if (!UserSession.isLoggedIn() || !"ADMIN".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: ADMIN role required.");
        }
    }

    public boolean rebuildErpDatabase() {
        requireAdmin();
        return maintenanceService.rebuildDatabase();
    }

    public boolean resetSemesterData() {
        requireAdmin();
        return maintenanceService.resetSemesterData();
    }

    public boolean initializeNewSemester(String semesterName) {
        requireAdmin();
        return maintenanceService.initializeNewSemester(semesterName);
    }

    public boolean openRegistration() {
        requireAdmin();
        return maintenanceService.openRegistration();
    }

    public boolean closeRegistration() {
        requireAdmin();
        return maintenanceService.closeRegistration();
    }
}


