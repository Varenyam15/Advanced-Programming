package edu.univ.erp.data;

import edu.univ.erp.domain.Section;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SectionRepository {

    private final Connection conn;

    public SectionRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null. Check DatabaseConfig and JDBC dependency.");
        }
        createTableIfNotExists(); // Ensure table exists on startup
    }

    public void createTableIfNotExists() {
        // FIX: Added 'semester VARCHAR(50)' which was missing before
        String sql = """
            CREATE TABLE IF NOT EXISTS sections (
              section_id INT AUTO_INCREMENT PRIMARY KEY,
              course_id VARCHAR(50) NOT NULL,
              instructor_id INT NOT NULL,
              semester VARCHAR(50),
              schedule VARCHAR(100),
              room VARCHAR(50),
              capacity INT,
              
              FOREIGN KEY(course_id) REFERENCES courses(course_id),
              FOREIGN KEY(instructor_id) REFERENCES instructors(instructor_id)
            );
            """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error creating sections table: " + e.getMessage());
        }
    }

    public boolean insertSection(Section section) {
        // FIX: Added 'semester' to insert
        String sql = """
            INSERT INTO sections(course_id, instructor_id, semester, schedule, room, capacity)
            VALUES (?, ?, ?, ?, ?, ?);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, section.getCourseId());
            ps.setInt(2, section.getInstructorId());
            ps.setString(3, section.getSemester()); // Setting the semester
            ps.setString(4, section.getSchedule());
            ps.setString(5, section.getRoom());
            ps.setInt(6, section.getCapacity());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error inserting section: " + e.getMessage());
            return false;
        }
    }

    public boolean updateSection(Section section) {
        // FIX: Added 'semester' to update
        String sql = """
            UPDATE sections 
            SET course_id=?, instructor_id=?, semester=?, schedule=?, room=?, capacity=?
            WHERE section_id=?;
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, section.getCourseId());
            ps.setInt(2, section.getInstructorId());
            ps.setString(3, section.getSemester());
            ps.setString(4, section.getSchedule());
            ps.setString(5, section.getRoom());
            ps.setInt(6, section.getCapacity());
            ps.setInt(7, section.getSectionId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating section: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteSection(int sectionId) {
        String sql = "DELETE FROM sections WHERE section_id = ?;";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sectionId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting section: " + e.getMessage());
            return false;
        }
    }

    public Section getSectionById(int sectionId) {
        String sql = "SELECT * FROM sections WHERE section_id = ?;";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sectionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching section: " + e.getMessage());
        }
        return null;
    }

    public List<Section> getAllSections() {
        List<Section> list = new ArrayList<>();
        String sql = "SELECT * FROM sections;";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching sections: " + e.getMessage());
        }
        return list;
    }

    // Helper to avoid repeating this code
    private Section mapRow(ResultSet rs) throws SQLException {
        return new Section(
                rs.getInt("section_id"),
                rs.getString("course_id"),
                rs.getInt("instructor_id"),
                rs.getString("semester"), // This reads the column that was missing
                rs.getString("schedule"),
                rs.getString("room"),
                rs.getInt("capacity")
        );
    }
}