package edu.univ.erp.domain;


public class Grade {

    private int gradeId;
    private int enrollmentId;
    private String letterGrade;
    private double gradePoints;





    public Grade() {

    }

    public Grade(int gradeId, int enrollmentId, String letterGrade, double gradePoints) {
        this.gradeId = gradeId;
        this.enrollmentId = enrollmentId;
        this.letterGrade = letterGrade;
        this.gradePoints = gradePoints;
    }





    public int getGradeId() {
        return gradeId;
    }

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }

    public int getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getLetterGrade() {
        return letterGrade;
    }

    public void setLetterGrade(String letterGrade) {
        this.letterGrade = letterGrade;
    }

    public double getGradePoints() {
        return gradePoints;
    }

    public void setGradePoints(double gradePoints) {
        this.gradePoints = gradePoints;
    }





    @Override
    public String toString() {
        return "Grade {" +
                "gradeId=" + gradeId +
                ", enrollmentId=" + enrollmentId +
                ", letterGrade='" + letterGrade + '\'' +
                ", gradePoints=" + gradePoints +
                '}';
    }
}
