package edu.univ.erp.api.instructor;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Grade;
import edu.univ.erp.service.InstructorService;
import edu.univ.erp.domain.Enrollment;

import java.util.List;


public class InstructorGradesAPI {

    private final InstructorService instructorService;

    public InstructorGradesAPI() {
        this.instructorService = new InstructorService();
    }

    private void requireInstructor() {
        if (!UserSession.isLoggedIn() || !"INSTRUCTOR".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: INSTRUCTOR role required.");
        }
    }

    public List<Grade> getGradesForSection(int sectionId) {
        requireInstructor();
        return instructorService.getGradesForSection(sectionId);
    }

    public List<Enrollment> getEnrollmentsForSection(int sectionId) {
        requireInstructor();

        return instructorService.getEnrollmentsForSection(sectionId);
    }


    public boolean assignGrade(int enrollmentId, String letterGrade, double gradePoints) {
        requireInstructor();
        return instructorService.assignOrUpdateGrade(enrollmentId, letterGrade, gradePoints);
    }
}

