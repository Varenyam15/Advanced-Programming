package edu.univ.erp.data;

import edu.univ.erp.domain.Instructor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class InstructorRepository {

    private final Connection conn;

    public InstructorRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null. Check DatabaseConfig and JDBC dependency.");
        }
        createTableIfNotExists();
    }

    public void createTableIfNotExists() {
        String sql = """
        CREATE TABLE IF NOT EXISTS instructors (
          instructor_id INT PRIMARY KEY,
          first_name VARCHAR(100) NOT NULL,
          last_name VARCHAR(100) NOT NULL,
          email VARCHAR(100) UNIQUE NOT NULL,
          department VARCHAR(100)
        );
        """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Instructors table verified/created.");
        } catch (SQLException e) {
            System.err.println("Error creating instructors table: " + e.getMessage());
        }
    }

    public boolean insertInstructor(Instructor instructor) {
        String sql = """
            INSERT INTO instructors(instructor_id, first_name, last_name, email, department)
            VALUES (?, ?, ?, ?, ?);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, instructor.getInstructorId());
            ps.setString(2, instructor.getFirstName());
            ps.setString(3, instructor.getLastName());
            ps.setString(4, instructor.getEmail());
            ps.setString(5, instructor.getDepartment());
            return ps.executeUpdate() > 0;
            } catch (SQLException e) {
            System.err.println("Error inserting instructor: " + e.getMessage());
            return false;
        }
    }

    public boolean updateInstructor(Instructor instructor) {
        String sql = """
            UPDATE instructors
            SET first_name=?, last_name=?, email=?, department=?
            WHERE instructor_id=?;
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, instructor.getFirstName());
            ps.setString(2, instructor.getLastName());
            ps.setString(3, instructor.getEmail());
            ps.setString(4, instructor.getDepartment());
            ps.setInt(5, instructor.getInstructorId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error updating instructor: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteInstructor(int instructorId) {
        String sql = "DELETE FROM instructors WHERE instructor_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, instructorId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting instructor: " + e.getMessage());
            return false;
        }
    }

    public Instructor getInstructorById(int instructorId) {
        String sql = "SELECT * FROM instructors WHERE instructor_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, instructorId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Instructor(
                            rs.getInt("instructor_id"),
                            rs.getString("first_name"),
                            rs.getString("last_name"),
                            rs.getString("email"),
                            rs.getString("department")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching instructor: " + e.getMessage());
        }
        return null;
    }

    public List<Instructor> getAllInstructors() {
        List<Instructor> instructors = new ArrayList<>();
        String sql = "SELECT * FROM instructors;";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                instructors.add(new Instructor(
                        rs.getInt("instructor_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("department")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Error fetching instructors: " + e.getMessage());
        }

        return instructors;
    }
}

