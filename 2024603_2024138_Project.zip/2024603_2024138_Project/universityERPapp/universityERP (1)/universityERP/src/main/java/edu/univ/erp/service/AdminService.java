package edu.univ.erp.service;

import edu.univ.erp.data.*;
import edu.univ.erp.domain.*;

import java.util.List;


public class AdminService {


    private final StudentRepository studentRepo;
    private final InstructorRepository instructorRepo;
    private final CourseRepository courseRepo;
    private final SectionRepository sectionRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final GradeRepository gradeRepo;
    private final SettingsRepository settingsRepo;




    public AdminService() {
        this.studentRepo = new StudentRepository();
        this.instructorRepo = new InstructorRepository();
        this.courseRepo = new CourseRepository();
        this.sectionRepo = new SectionRepository();
        this.enrollmentRepo = new EnrollmentRepository();
        this.gradeRepo = new GradeRepository();
        this.settingsRepo = new SettingsRepository();
    }





    public boolean addStudent(Student student) {
        return studentRepo.insertStudent(student);
    }

    public boolean updateStudent(Student student) {
        return studentRepo.updateStudent(student);
    }

    public boolean deleteStudent(int studentId) {
        return studentRepo.deleteStudent(studentId);
    }

    public Student getStudentById(int id) {
        return studentRepo.getStudentById(id);
    }

    public List<Student> getAllStudents() {
        return studentRepo.getAllStudents();
    }





    public boolean addInstructor(Instructor instructor) {
        return instructorRepo.insertInstructor(instructor);
    }

    public boolean updateInstructor(Instructor instructor) {
        return instructorRepo.updateInstructor(instructor);
    }

    public boolean deleteInstructor(int instructorId) {
        return instructorRepo.deleteInstructor(instructorId);
    }

    public Instructor getInstructorById(int id) {
        return instructorRepo.getInstructorById(id);
    }

    public List<Instructor> getAllInstructors() {
        return instructorRepo.getAllInstructors();
    }





    public boolean addCourse(Course course) {
        return courseRepo.insertCourse(course);
    }

    public boolean updateCourse(Course course) {
        return courseRepo.updateCourse(course);
    }

    public boolean deleteCourse(String courseId) {
        return courseRepo.deleteCourse(courseId);
    }

    public Course getCourseById(String id) {
        return courseRepo.getCourseById(id);
    }

    public List<Course> getAllCourses() {
        return courseRepo.getAllCourses();
    }





    public boolean addSection(Section section) {
        return sectionRepo.insertSection(section);
    }

    public boolean updateSection(Section section) {
        return sectionRepo.updateSection(section);
    }

    public boolean deleteSection(int sectionId) {
        return sectionRepo.deleteSection(sectionId);
    }

    public Section getSectionById(int id) {
        return sectionRepo.getSectionById(id);
    }

    public List<Section> getAllSections() {
        return sectionRepo.getAllSections();
    }





    public List<Enrollment> getEnrollmentsByStudent(int studentId) {
        return enrollmentRepo.getEnrollmentsByStudent(studentId);
    }

    public List<Enrollment> getEnrollmentsBySection(int sectionId) {
        return enrollmentRepo.getEnrollmentsBySection(sectionId);
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepo.getAllEnrollments();
    }

    public Grade getGradeByEnrollment(int enrollmentId) {
        return gradeRepo.getGradeByEnrollmentId(enrollmentId);
    }

    public List<Grade> getAllGrades() {
        return gradeRepo.getAllGrades();
    }





    public boolean setSetting(String key, String value) {
        return settingsRepo.saveOrUpdateSetting(new Setting(key, value));
    }

    public Setting getSetting(String key) {
        return settingsRepo.getSetting(key);
    }

   /* public List<Setting> getAllSettings() {
        return settingsRepo.getAllSettings();
    }

    public boolean deleteSetting(String key) {
        return settingsRepo.deleteSetting(key);
    }*/



    public boolean createStudentProfile(String username, String firstName, String lastName, String email, String major) {

        Student s = new Student(0, firstName, lastName, email, major, 1);


        return studentRepo.insertStudent(s);

    }

    public boolean createInstructorProfile(String username, String firstName, String lastName, String email, String dept) {
        Instructor i = new Instructor(0, firstName, lastName, email, dept);
        return instructorRepo.insertInstructor(i);
    }
}
