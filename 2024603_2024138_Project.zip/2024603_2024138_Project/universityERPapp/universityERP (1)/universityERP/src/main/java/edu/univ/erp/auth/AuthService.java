package edu.univ.erp.auth;

import edu.univ.erp.auth.model.AuthUser;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;


public class AuthService {

    private final AuthRepository authRepository;

    public AuthService() {
        this.authRepository = new AuthRepository();
    }










    public AuthUser login(String username, String password) {
        AuthUser user = authRepository.getUserByUsername(username);
        if (user == null) return null;


        String salt = user.getSalt();

        String hashedInput = PasswordHasher.hash(password, salt);


        if (!hashedInput.equals(user.getPasswordHash())) {
            return null;
        }
        return user;
    }


    public AuthUser loginAndGetUser(String username, String password) {
        return login(username, password);
    }





    public boolean registerUser(String username, String password, String role) {
        if (userExists(username)) {
            return false;
        }

        String salt = PasswordHasher.generateSalt();


        String hashed = PasswordHasher.hash(password, salt);


        AuthUser user = new AuthUser(username, hashed, role);
        user.setSalt(salt);

        return authRepository.insertUser(user);
    }

    public boolean userExists(String username) {
        return authRepository.getUserByUsername(username) != null;
    }





    public boolean updatePassword(String username, String newPassword) {

        String newSalt = PasswordHasher.generateSalt();
        String newHash = PasswordHasher.hash(newPassword, newSalt);


        return authRepository.updatePassword(username, newHash, newSalt);
    }

    public boolean deleteUser(String username) {
        AuthUser user = authRepository.getUserByUsername(username);
        if (user == null) return false;
        return authRepository.deleteUser(user.getUserId());
    }





    public AuthUser getUserByUsername(String username) {
        return authRepository.getUserByUsername(username);
    }

    public AuthUser getUserById(int id) {
        return authRepository.getUserById(id);
    }
}


