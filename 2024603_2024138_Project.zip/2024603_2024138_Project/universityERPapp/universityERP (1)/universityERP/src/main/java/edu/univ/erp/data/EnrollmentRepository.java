package edu.univ.erp.data;

import edu.univ.erp.domain.Enrollment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class EnrollmentRepository {

    private final Connection conn;

    public EnrollmentRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null. Check DatabaseConfig and JDBC dependency.");
        }
        createTableIfNotExists();
    }




    public void createTableIfNotExists() {
        String sql = """
        CREATE TABLE IF NOT EXISTS enrollments (
          enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
          student_id INT NOT NULL,
          section_id INT NOT NULL,
          status VARCHAR(50),

          FOREIGN KEY(student_id) REFERENCES students(student_id),
          FOREIGN KEY(section_id) REFERENCES sections(section_id)
        );
        """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Enrollments table verified/created.");
        } catch (SQLException e) {
            System.err.println("Error creating enrollments table: " + e.getMessage());
        }
    }




    public boolean insertEnrollment(Enrollment enrollment) {
        String sql = """
            INSERT INTO enrollments(student_id, section_id, status)
            VALUES (?, ?, ?);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, enrollment.getStudentId());
            ps.setInt(2, enrollment.getSectionId());
            ps.setString(3, enrollment.getStatus());

            int affected = ps.executeUpdate();
            if (affected == 0) return false;

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    enrollment.setEnrollmentId(keys.getInt(1));
                }
            }
            return true;

        } catch (SQLException e) {
            System.err.println("Error inserting enrollment: " + e.getMessage());
            return false;
        }
    }




    public boolean updateEnrollment(Enrollment enrollment) {
        String sql = """
            UPDATE enrollments
            SET student_id=?, section_id=?, status=?
            WHERE enrollment_id=?;
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, enrollment.getStudentId());
            ps.setInt(2, enrollment.getSectionId());
            ps.setString(3, enrollment.getStatus());
            ps.setInt(4, enrollment.getEnrollmentId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error updating enrollment: " + e.getMessage());
            return false;
        }
    }




    public boolean deleteEnrollment(int enrollmentId) {
        String sql = "DELETE FROM enrollments WHERE enrollment_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, enrollmentId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting enrollment: " + e.getMessage());
            return false;
        }
    }




    public Enrollment getEnrollmentById(int enrollmentId) {
        String sql = "SELECT * FROM enrollments WHERE enrollment_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, enrollmentId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Enrollment(
                            rs.getInt("enrollment_id"),
                            rs.getInt("student_id"),
                            rs.getInt("section_id"),
                            rs.getString("status")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching enrollment: " + e.getMessage());
        }
        return null;
    }




    public List<Enrollment> getEnrollmentsByStudent(int studentId) {
        List<Enrollment> list = new ArrayList<>();
        String sql = "SELECT * FROM enrollments WHERE student_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Enrollment(
                            rs.getInt("enrollment_id"),
                            rs.getInt("student_id"),
                            rs.getInt("section_id"),
                            rs.getString("status")
                    ));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching enrollments by student: " + e.getMessage());
        }

        return list;
    }




    public List<Enrollment> getEnrollmentsBySection(int sectionId) {
        List<Enrollment> list = new ArrayList<>();
        String sql = "SELECT * FROM enrollments WHERE section_id = ?;";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, sectionId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Enrollment(
                            rs.getInt("enrollment_id"),
                            rs.getInt("student_id"),
                            rs.getInt("section_id"),
                            rs.getString("status")
                    ));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching enrollments by section: " + e.getMessage());
        }

        return list;
    }




    public List<Enrollment> getAllEnrollments() {
        List<Enrollment> list = new ArrayList<>();
        String sql = "SELECT * FROM enrollments;";

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Enrollment(
                        rs.getInt("enrollment_id"),
                        rs.getInt("student_id"),
                        rs.getInt("section_id"),
                        rs.getString("status")
                ));
            }

        } catch (SQLException e) {
            System.err.println("Error fetching enrollments: " + e.getMessage());
        }

        return list;
    }
}
