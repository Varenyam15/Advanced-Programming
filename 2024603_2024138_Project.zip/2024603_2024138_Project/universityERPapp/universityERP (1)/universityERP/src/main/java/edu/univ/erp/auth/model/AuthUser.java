package edu.univ.erp.auth.model;


public class AuthUser {

    private int userId;
    private String username;
    private String passwordHash;
    private String role;
    private String salt;





    public AuthUser() {

    }

    public AuthUser(int userId, String username, String passwordHash, String role, String salt) {
        this.userId = userId;
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
        this.salt=salt;
    }

    public AuthUser(String username, String passwordHash, String role) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
    }





    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setSalt(String salt){this.salt=salt;}

    public String getSalt(){return salt;}





    @Override
    public String toString() {
        return "AuthUser {" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
