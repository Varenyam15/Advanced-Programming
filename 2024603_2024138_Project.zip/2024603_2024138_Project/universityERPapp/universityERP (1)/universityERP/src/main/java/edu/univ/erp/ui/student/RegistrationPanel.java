package edu.univ.erp.ui.student;

import edu.univ.erp.api.student.StudentRegistrationAPI;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Enrollment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class RegistrationPanel extends JPanel {

    private final StudentRegistrationAPI registrationAPI;

    private final JTable availableTable;
    private final DefaultTableModel availableModel;

    private final JTable registeredTable;
    private final DefaultTableModel registeredModel;

    private final JButton registerButton;
    private final JButton dropButton;
    private final JButton refreshButton;

    public RegistrationPanel() {
        this.registrationAPI = new StudentRegistrationAPI();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel title = new JLabel("Course Registration", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        add(title, BorderLayout.NORTH);

        String[] availableCols = { "Section ID", "Course ID", "Instructor ID", "Semester", "Schedule", "Room", "Capacity" };
        availableModel = new DefaultTableModel(availableCols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        availableTable = new JTable(availableModel);
        availableTable.setAutoCreateRowSorter(true);
        JScrollPane availableScroll = new JScrollPane(availableTable);

        String[] registeredCols = { "Enrollment ID", "Section ID", "Course ID", "Semester" };
        registeredModel = new DefaultTableModel(registeredCols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        registeredTable = new JTable(registeredModel);
        registeredTable.setAutoCreateRowSorter(true);
        JScrollPane registeredScroll = new JScrollPane(registeredTable);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, availableScroll, registeredScroll);
        splitPane.setResizeWeight(0.5);
        add(splitPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        registerButton = new JButton("Register");
        dropButton = new JButton("Drop");
        refreshButton = new JButton("Refresh");
        buttonPanel.add(registerButton);
        buttonPanel.add(dropButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        registerButton.addActionListener(e -> onRegister());
        dropButton.addActionListener(e -> onDrop());
        refreshButton.addActionListener(e -> loadAll());

        loadAll();
    }

    private Integer getSelectedAvailableSectionId() {
        int row = availableTable.getSelectedRow();
        if (row < 0) return null;
        Object v = availableModel.getValueAt(row, 0);
        if (v == null) return null;
        try { return Integer.parseInt(String.valueOf(v)); } catch (Exception ex) { return null; }
    }

    private Integer getSelectedEnrollmentId() {
        int row = registeredTable.getSelectedRow();
        if (row < 0) return null;
        Object v = registeredModel.getValueAt(row, 0);
        if (v == null) return null;
        try { return Integer.parseInt(String.valueOf(v)); } catch (Exception ex) { return null; }
    }

    private void loadAll() {
        availableModel.setRowCount(0);
        List<Section> available = registrationAPI.getAvailableSections();
        if (available != null) {
            for (Section s : available) {
                availableModel.addRow(new Object[] {
                        s.getSectionId(), s.getCourseId(), s.getInstructorId(), s.getSemester(),
                        s.getSchedule(), s.getRoom(), s.getCapacity()
                });
            }
        }

        registeredModel.setRowCount(0);
        List<Enrollment> regs = registrationAPI.getMyRegistrations();
        if (regs != null) {
            for (Enrollment e : regs) {
                registeredModel.addRow(new Object[] {
                        e.getEnrollmentId(), e.getSectionId(), e.getCourseId(), e.getSemester()
                });
            }
        }
    }

    private void onRegister() {
        Integer sectionId = getSelectedAvailableSectionId();
        if (sectionId == null) {
            JOptionPane.showMessageDialog(this, "Select a section.", "No selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        boolean ok = registrationAPI.registerSection(sectionId);
        JOptionPane.showMessageDialog(this, ok ? "Registered" : "Registration failed");
        loadAll();
    }

    private void onDrop() {
        Integer enrollmentId = getSelectedEnrollmentId();
        if (enrollmentId == null) {
            JOptionPane.showMessageDialog(this, "Select a registration to drop.", "No selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        boolean ok = registrationAPI.dropSection(enrollmentId);
        JOptionPane.showMessageDialog(this, ok ? "Dropped" : "Drop failed");
        loadAll();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Registration Panel (Test)");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setSize(900, 550);
            f.setLocationRelativeTo(null);
            f.setContentPane(new RegistrationPanel());
            f.setVisible(true);
        });
    }
}
