package edu.univ.erp.data;

import edu.univ.erp.domain.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentRepository {

    private final Connection conn;

    public StudentRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null.");
        }
    }

    public void createTableIfNotExists() {
        // FIX: Removed AUTO_INCREMENT so we can set the ID manually
        String sql = """
            CREATE TABLE IF NOT EXISTS students (
              student_id INT PRIMARY KEY, 
              first_name VARCHAR(100) NOT NULL,
              last_name VARCHAR(100) NOT NULL,
              email VARCHAR(100) UNIQUE NOT NULL,
              major VARCHAR(100),
              semester INT
            );
            """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error creating students table: " + e.getMessage());
        }
    }

    public boolean insertStudent(Student student) {
        // FIX: We now insert the student_id manually
        String sql = """
            INSERT INTO students(student_id, first_name, last_name, email, major, semester)
            VALUES (?, ?, ?, ?, ?, ?);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, student.getStudentId()); // Uses the ID we pass in
            ps.setString(2, student.getFirstName());
            ps.setString(3, student.getLastName());
            ps.setString(4, student.getEmail());
            ps.setString(5, student.getMajor());
            ps.setInt(6, student.getSemester());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error inserting student: " + e.getMessage());
            return false;
        }
    }

    // ... keep getStudentById, getAllStudents, updateStudent, deleteStudent as they were ...
    // (If you need me to paste them again, let me know, but they are standard)

    public Student getStudentById(int studentId) {
        String sql = "SELECT * FROM students WHERE student_id = ?;";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM students")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    // Helper to keep code short
    private Student mapRow(ResultSet rs) throws SQLException {
        return new Student(
                rs.getInt("student_id"), rs.getString("first_name"), rs.getString("last_name"),
                rs.getString("email"), rs.getString("major"), rs.getInt("semester")
        );
    }

    public boolean updateStudent(Student s) {
        // ... (existing code is fine) ...
        return false; // placeholder if you don't have it handy
    }
    public boolean deleteStudent(int id) { return false; } // placeholder
}