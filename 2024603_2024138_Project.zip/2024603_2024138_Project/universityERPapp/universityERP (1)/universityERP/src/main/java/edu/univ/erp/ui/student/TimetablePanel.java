package edu.univ.erp.ui.student;

import edu.univ.erp.api.student.StudentTimetableAPI;
import edu.univ.erp.domain.Section;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TimetablePanel extends JPanel {

    private final StudentTimetableAPI timetableAPI;

    private final JTable timetableTable;
    private final DefaultTableModel tableModel;

    private final JButton refreshButton;

    public TimetablePanel() {
        this.timetableAPI = new StudentTimetableAPI();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("My Timetable", SwingConstants.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 18f));
        add(titleLabel, BorderLayout.NORTH);

        String[] cols = { "Section ID", "Course ID", "Semester", "Schedule", "Room", "Capacity" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        timetableTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(timetableTable);
        add(scrollPane, BorderLayout.CENTER);

        refreshButton = new JButton("Refresh");
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(refreshButton);
        add(bottomPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> loadTimetable());

        loadTimetable();
    }

    private void loadTimetable() {
        tableModel.setRowCount(0);
        List<Section> sections = timetableAPI.getMyTimetable();
        if (sections == null) {
            return;
        }
        for (Section s : sections) {
            tableModel.addRow(new Object[] {
                    s.getSectionId(),
                    s.getCourseId(),
                    s.getSemester(),
                    s.getSchedule(),
                    s.getRoom(),
                    s.getCapacity()
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Timetable Panel (Test)");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setSize(900, 500);
            f.setLocationRelativeTo(null);
            f.setContentPane(new TimetablePanel());
            f.setVisible(true);
        });
    }
}
