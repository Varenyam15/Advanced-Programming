package edu.univ.erp.service;

import edu.univ.erp.data.*;
import edu.univ.erp.domain.*;

import java.util.List;
import java.util.stream.Collectors;


public class StudentService {

    private final StudentRepository studentRepo;
    private final CourseRepository courseRepo;
    private final SectionRepository sectionRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final GradeRepository gradeRepo;
    private final SettingsRepository settingsRepo;
    private final MaintenanceService maintenanceService;




    public StudentService() {
        this.studentRepo = new StudentRepository();
        this.courseRepo = new CourseRepository();
        this.sectionRepo = new SectionRepository();
        this.enrollmentRepo = new EnrollmentRepository();
        this.gradeRepo = new GradeRepository();
        this.settingsRepo = new SettingsRepository();
        this.maintenanceService = new MaintenanceService();
    }





    public Student getStudentById(int studentId) {
        return studentRepo.getStudentById(studentId);
    }

    public boolean updateStudentProfile(Student student) {
        return studentRepo.updateStudent(student);
    }





    public boolean isRegistrationOpen() {
        Setting s = settingsRepo.getSetting("REGISTRATION_STATUS");
        return s != null && s.getSettingValue().equalsIgnoreCase("OPEN");
    }





    public List<Course> getAllCourses() {
        return courseRepo.getAllCourses();
    }

    public List<Section> getSectionsForCourse(String courseId) {
        return sectionRepo.getAllSections().stream()
                .filter(s -> s.getCourseId().equalsIgnoreCase(courseId))
                .collect(Collectors.toList());
    }






    public String registerForSection(int studentId, int sectionId) {

        if (maintenanceService.isMaintenanceMode()) {
            return "System is in Maintenance Mode. Try again later.";
        }

        if (!isRegistrationOpen()) {
            return "Registration is currently CLOSED.";
        }

        Section section = sectionRepo.getSectionById(sectionId);
        if (section == null) {
            return "Section does not exist.";
        }

        List<Enrollment> current = enrollmentRepo.getEnrollmentsBySection(sectionId);

        if (current.size() >= section.getCapacity()) {
            return "Section is full.";
        }


        boolean alreadyEnrolled = enrollmentRepo.getEnrollmentsByStudent(studentId)
                .stream()
                .anyMatch(e -> e.getSectionId() == sectionId);

        if (alreadyEnrolled) {
            return "You are already enrolled in this section.";
        }

        Enrollment enrollment = new Enrollment(0, studentId, sectionId, "ENROLLED");

        boolean ok = enrollmentRepo.insertEnrollment(enrollment);
        return ok ? "Registration successful!" : "Registration failed.";
    }





    public List<Enrollment> getMyEnrollments(int studentId) {
        List<Enrollment> enrollments = enrollmentRepo.getEnrollmentsByStudent(studentId);
        for (Enrollment e : enrollments) {
            Section s = sectionRepo.getSectionById(e.getSectionId());
            if (s != null) {
                e.setCourseId(s.getCourseId());
                e.setSemester(s.getSemester());
            }
        }

        return enrollments;
    }

    public boolean dropSection(int studentId, int enrollmentId) {

        if (maintenanceService.isMaintenanceMode()) {
            return false; // Blocked
        }

        if (!isRegistrationOpen()) {
            System.out.println("Drop failed: Registration is closed.");
            return false;
        }

        return enrollmentRepo.deleteEnrollment(enrollmentId);
    }



    public List<Grade> getMyGrades(int studentId) {
        return enrollmentRepo.getEnrollmentsByStudent(studentId).stream()
                .map(e -> gradeRepo.getGradeByEnrollmentId(e.getEnrollmentId()))
                .filter(g -> g != null)
                .collect(Collectors.toList());
    }

    public double calculateGPA(int studentId) {
        List<Grade> grades = getMyGrades(studentId);

        if (grades.isEmpty()) return 0.0;

        double total = grades.stream()
                .mapToDouble(Grade::getGradePoints)
                .sum();

        return total / grades.size();
    }





    public String getEnrollmentDisplayLine(Enrollment e) {
        Section s = sectionRepo.getSectionById(e.getSectionId());
        Course c = courseRepo.getCourseById(s.getCourseId());
        Grade g = gradeRepo.getGradeByEnrollmentId(e.getEnrollmentId());

        return String.format(
                "%s (%s) | Section %d | Status: %s | Grade: %s",
                c.getCourseName(),
                c.getCourseId(),
                s.getSectionId(),
                e.getStatus(),
                (g == null ? "Not Assigned" : g.getLetterGrade())
        );
    }
}
