package edu.univ.erp.ui.student;

import edu.univ.erp.api.catalog.CatalogAPI;
import edu.univ.erp.domain.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CourseCatalogPanel extends JPanel {

    private final CatalogAPI catalogAPI;

    private final JTable courseTable;
    private final DefaultTableModel tableModel;

    private final JButton refreshButton;

    public CourseCatalogPanel() {
        this.catalogAPI = new CatalogAPI();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Course Catalog", SwingConstants.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 18f));
        add(titleLabel, BorderLayout.NORTH);

        String[] cols = { "Course ID", "Title", "Department", "Credits" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        courseTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(courseTable);
        add(scrollPane, BorderLayout.CENTER);

        refreshButton = new JButton("Refresh");
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(refreshButton);
        add(bottomPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> loadCourses());

        loadCourses();
    }

    private void loadCourses() {
        tableModel.setRowCount(0);
        List<Course> courses = catalogAPI.getAllCourses();
        if (courses == null) {
            return;
        }
        for (Course c : courses) {
            tableModel.addRow(new Object[] {
                    c.getCourseId(),
                    c.getCourseName(),
                    c.getDepartment(),
                    c.getCredits()
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Course Catalog Panel (Test)");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900, 500);
            frame.setLocationRelativeTo(null);
            frame.setContentPane(new CourseCatalogPanel());
            frame.setVisible(true);
        });
    }
}

