package edu.univ.erp.api.student;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.CatalogService;
import edu.univ.erp.service.StudentService;

import java.lang.reflect.Method;
import java.util.List;

public class StudentRegistrationAPI {

    private final StudentService studentService;
    private final CatalogService catalogService;

    public StudentRegistrationAPI() {
        this.studentService = new StudentService();
        this.catalogService = new CatalogService();
    }

    private void requireStudent() {
        if (!UserSession.isLoggedIn() || !"STUDENT".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: STUDENT role required.");
        }
    }

    public List<Section> getAvailableSections() {
        requireStudent();
        return catalogService.getAllSections();
    }

    public boolean registerSection(int sectionId) {
        requireStudent();
        int studentId = UserSession.getUserId();

        String result = studentService.registerForSection(studentId, sectionId);

        return "Registration successful!".equals(result);
    }

    public boolean dropSection(int enrollmentId) {
        requireStudent();
        requireStudent();
        int studentId = UserSession.getUserId();


        return studentService.dropSection(studentId, enrollmentId);
    }

    public List<Enrollment> getMyRegistrations() {
        requireStudent();
        int studentId = UserSession.getUserId();
        return studentService.getMyEnrollments(studentId);
    }

    private static Method findMethod(Class<?> cls, String name, Class<?>... paramTypes) {
        try {
            return cls.getMethod(name, paramTypes);
        } catch (NoSuchMethodException e) {
            try {
                return cls.getDeclaredMethod(name, paramTypes);
            } catch (NoSuchMethodException ex) {
                return null;
            }
        }
    }

    private static Object invokeIfExists(Object target, String name, Class<?> firstParamType, Object... args) throws Exception {
        Method m = findMethod(target.getClass(), name, firstParamType, int.class);
        if (m == null) {
            m = findMethod(target.getClass(), name, int.class, int.class);
            if (m == null) {
                m = findMethod(target.getClass(), name, int.class);
                if (m == null) {
                    return null;
                }
            }
        }
        m.setAccessible(true);
        return m.invoke(target, args);
    }
}



