package edu.univ.erp.ui.instructor;

import edu.univ.erp.api.instructor.InstructorGradesAPI;
import edu.univ.erp.api.instructor.InstructorSectionAPI;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Grade;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Student;
import edu.univ.erp.service.InstructorService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class GradeEntryPanel extends JPanel {

    private final InstructorSectionAPI sectionAPI;
    private final InstructorGradesAPI gradesAPI;


    private final InstructorService instructorService;

    private final JComboBox<SectionItem> sectionCombo;
    private final JTable gradesTable;
    private final DefaultTableModel tableModel;

    private final JTextField enrollmentIdField;
    private final JTextField studentNameField; // Visual aid only
    private final JTextField letterGradeField;
    private final JTextField gradePointsField;

    private final JButton loadButton;
    private final JButton saveButton;
    private final JButton clearButton;
    private final JButton exportButton;

    private final JLabel statsLabel;

    public GradeEntryPanel() {
        this.sectionAPI = new InstructorSectionAPI();
        this.gradesAPI = new InstructorGradesAPI();
        this.instructorService = new InstructorService();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Select Section:"));
        sectionCombo = new JComboBox<>();
        sectionCombo.setPreferredSize(new Dimension(200, 25));
        loadButton = new JButton("Load Students");
        topPanel.add(sectionCombo);
        topPanel.add(loadButton);
        add(topPanel, BorderLayout.NORTH);


        String[] cols = { "Enrollment ID", "Student Name", "Student ID", "Current Grade", "Points" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        gradesTable = new JTable(tableModel);
        gradesTable.setAutoCreateRowSorter(true);
        add(new JScrollPane(gradesTable), BorderLayout.CENTER);


        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Assign Grade"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Enrollment ID:"), gbc);
        gbc.gridx = 1;
        enrollmentIdField = new JTextField(10);
        enrollmentIdField.setEditable(false);
        formPanel.add(enrollmentIdField, gbc);

        gbc.gridx = 2;
        formPanel.add(new JLabel("Student:"), gbc);
        gbc.gridx = 3;
        studentNameField = new JTextField(15);
        studentNameField.setEditable(false);
        formPanel.add(studentNameField, gbc);


        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Letter Grade:"), gbc);
        gbc.gridx = 1;
        letterGradeField = new JTextField(5);
        formPanel.add(letterGradeField, gbc);

        gbc.gridx = 2;
        formPanel.add(new JLabel("Grade Points (0-4):"), gbc);
        gbc.gridx = 3;
        gradePointsField = new JTextField(5);
        formPanel.add(gradePointsField, gbc);

        // Row 3: Buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        saveButton = new JButton("Save Grade");
        clearButton = new JButton("Clear");
        exportButton = new JButton("Export to CSV");
        actionPanel.add(saveButton);
        actionPanel.add(clearButton);
        actionPanel.add(exportButton);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 4;
        formPanel.add(actionPanel, gbc);

        add(formPanel, BorderLayout.SOUTH);


        loadSections();

        loadButton.addActionListener(e -> onLoadStudents());
        saveButton.addActionListener(e -> onSaveGrade());
        clearButton.addActionListener(e -> clearForm());
        exportButton.addActionListener(e -> onExport());

        statsLabel = new JLabel("Class Average: -");
        formPanel.add(statsLabel, gbc);


        gradesTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = gradesTable.getSelectedRow();
                if (row >= 0) {
                    // Column 0 is Enrollment ID
                    enrollmentIdField.setText(tableModel.getValueAt(row, 0).toString());
                    // Column 1 is Name
                    studentNameField.setText(tableModel.getValueAt(row, 1).toString());


                    Object grade = tableModel.getValueAt(row, 3);
                    Object points = tableModel.getValueAt(row, 4);
                    letterGradeField.setText(grade != null ? grade.toString() : "");
                    gradePointsField.setText(points != null ? points.toString() : "");
                }
            }
        });
    }

    private void loadSections() {
        sectionCombo.removeAllItems();
        try {
            List<Section> sections = sectionAPI.getMySections();
            if (sections != null) {
                for (Section s : sections) {
                    sectionCombo.addItem(new SectionItem(s.getSectionId(), "Section " + s.getSectionId() + " (" + s.getCourseId() + ")"));
                }
            }
        } catch (Exception e) {

        }
    }

    private void onLoadStudents() {
        double totalPoints = 0;
        int gradedCount = 0;
        SectionItem selected = (SectionItem) sectionCombo.getSelectedItem();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Select a section first.");
            return;
        }



        tableModel.setRowCount(0);




        List<Enrollment> enrollments = gradesAPI.getEnrollmentsForSection(selected.sectionId);

        if (enrollments == null || enrollments.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No students enrolled in this section.");
            return;
        }


        edu.univ.erp.data.StudentRepository studentRepo = new edu.univ.erp.data.StudentRepository();
        edu.univ.erp.data.GradeRepository gradeRepo = new edu.univ.erp.data.GradeRepository();


        for (Enrollment e : enrollments) {

            Student s = studentRepo.getStudentById(e.getStudentId());


            Grade g = gradeRepo.getGradeByEnrollmentId(e.getEnrollmentId());

            String name = (s != null) ? s.getFirstName() + " " + s.getLastName() : "Unknown";
            String grade = (g != null) ? g.getLetterGrade() : "-";
            String points = (g != null) ? String.valueOf(g.getGradePoints()) : "-";

            if (g != null) {
                totalPoints += g.getGradePoints();
                gradedCount++;
            }

            if (gradedCount > 0) {
                double avg = totalPoints / gradedCount;
                statsLabel.setText(String.format("Class Average: %.2f", avg));
            } else {
                statsLabel.setText("Class Average: N/A");
            }

            tableModel.addRow(new Object[]{
                    e.getEnrollmentId(),
                    name,
                    e.getStudentId(),
                    grade,
                    points
            });

        }
    }

    private void onSaveGrade() {
        try {
            String enrollIdStr = enrollmentIdField.getText().trim();
            if (enrollIdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select a student from the table.");
                return;
            }
            int enrollmentId = Integer.parseInt(enrollIdStr);
            String letter = letterGradeField.getText().trim();
            double points = Double.parseDouble(gradePointsField.getText().trim());

            boolean ok = gradesAPI.assignGrade(enrollmentId, letter, points);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Grade Saved!");
                onLoadStudents();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Error saving grade.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Points must be a number (e.g. 4.0)");
        }
    }

    private void clearForm() {
        enrollmentIdField.setText("");
        studentNameField.setText("");
        letterGradeField.setText("");
        gradePointsField.setText("");
        gradesTable.clearSelection();
    }

    private void onExport() {

        if (gradesTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No data to export. Please 'Load Students' first.");
            return;
        }


        String defaultName = "Grades_Export.csv";


        boolean success = edu.univ.erp.util.CSVExporter.exportTable(gradesTable, defaultName);

        if (success) {
            JOptionPane.showMessageDialog(this, "Export Successful!");
        }
    }

    private record SectionItem(int sectionId, String label) {
        @Override public String toString() { return label; }
    }
}