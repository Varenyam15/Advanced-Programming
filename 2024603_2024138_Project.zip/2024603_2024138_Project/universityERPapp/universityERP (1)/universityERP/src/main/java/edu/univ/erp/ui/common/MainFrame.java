package edu.univ.erp.ui.common;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private final JPanel contentPanel;

    public MainFrame(String title, JPanel content) {
        super(title);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        contentPanel = new JPanel(new BorderLayout());
        setContent(content);

        add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    public void setContent(JPanel panel) {
        contentPanel.removeAll();
        contentPanel.add(panel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
}
