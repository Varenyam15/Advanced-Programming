package edu.univ.erp.domain;

public class Section {
    private int sectionId;
    private String courseId;
    private int instructorId;
    private String semester;
    private String schedule;
    private String room;
    private int capacity;

    public Section() {}

    public Section(int sectionId, String courseId, int instructorId, String semester,
                   String schedule, String room, int capacity) {
        this.sectionId = sectionId;
        this.courseId = courseId;
        this.instructorId = instructorId;
        this.semester = semester;
        this.schedule = schedule;
        this.room = room;
        this.capacity = capacity;
    }

    public int getSectionId() {
        return sectionId;
    }

    public void setSectionId(int sectionId) {
        this.sectionId = sectionId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public int getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(int instructorId) {
        this.instructorId = instructorId;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "Section {" +
                "sectionId=" + sectionId +
                ", courseId='" + courseId + '\'' +
                ", instructorId=" + instructorId +
                ", semester='" + semester + '\'' +
                ", schedule='" + schedule + '\'' +
                ", room='" + room + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}

