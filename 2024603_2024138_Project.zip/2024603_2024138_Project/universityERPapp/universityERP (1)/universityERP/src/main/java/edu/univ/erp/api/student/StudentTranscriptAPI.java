package edu.univ.erp.api.student;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Grade;
import edu.univ.erp.service.StudentService;

import java.util.List;

public class StudentTranscriptAPI {

    private final StudentService studentService;

    public StudentTranscriptAPI() {
        this.studentService = new StudentService();
    }

    private void requireStudent() {
        if (!UserSession.isLoggedIn() || !"STUDENT".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: STUDENT role required.");
        }
    }

    public List<Grade> getMyTranscript() {
        requireStudent();
        int studentId = UserSession.getUserId();
        return studentService.getMyGrades(studentId);
    }

    public List<Grade> getMyGrades() {
        return getMyTranscript();
    }

    public Double getMyGpa() {
        requireStudent();
        int studentId = UserSession.getUserId();
        return studentService.calculateGPA(studentId);
    }
}


