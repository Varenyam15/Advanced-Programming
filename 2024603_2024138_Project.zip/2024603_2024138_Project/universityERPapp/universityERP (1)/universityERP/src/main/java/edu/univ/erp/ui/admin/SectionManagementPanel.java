package edu.univ.erp.ui.admin;

import edu.univ.erp.domain.Section;
import edu.univ.erp.service.AdminService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class SectionManagementPanel extends JPanel {

    private final AdminService adminService;


    private final JTable sectionTable;
    private final DefaultTableModel tableModel;

    private final JTextField sectionIdField;
    private final JTextField courseIdField;
    private final JTextField instructorIdField;
    private final JTextField semesterField;
    private final JTextField scheduleField;
    private final JTextField roomField;
    private final JSpinner capacitySpinner;

    private final JButton addButton;
    private final JButton updateButton;
    private final JButton deleteButton;
    private final JButton clearButton;
    private final JButton refreshButton;

    public SectionManagementPanel() {
        this.adminService = new AdminService();


        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


        JLabel titleLabel = new JLabel("Section Management", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);


        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Section Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Section ID (Auto):"), gbc);
        gbc.gridx = 1;
        sectionIdField = new JTextField(15);
        sectionIdField.setEditable(false); // Locked because it's Auto-Increment
        formPanel.add(sectionIdField, gbc);

        gbc.gridx = 2;
        formPanel.add(new JLabel("Course ID:"), gbc);
        gbc.gridx = 3;
        courseIdField = new JTextField(15);
        formPanel.add(courseIdField, gbc);


        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Instructor ID:"), gbc);
        gbc.gridx = 1;
        instructorIdField = new JTextField(15);
        formPanel.add(instructorIdField, gbc);

        gbc.gridx = 2;
        formPanel.add(new JLabel("Semester:"), gbc);
        gbc.gridx = 3;
        semesterField = new JTextField("Fall 2025", 15);
        formPanel.add(semesterField, gbc);


        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Schedule:"), gbc);
        gbc.gridx = 1;
        scheduleField = new JTextField(15);
        formPanel.add(scheduleField, gbc);

        gbc.gridx = 2;
        formPanel.add(new JLabel("Room:"), gbc);
        gbc.gridx = 3;
        roomField = new JTextField(15);
        formPanel.add(roomField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 1;
        capacitySpinner = new JSpinner(new SpinnerNumberModel(30, 1, 500, 1));
        formPanel.add(capacitySpinner, gbc);


        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        addButton = new JButton("Add Section");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear Form");
        refreshButton = new JButton("Refresh Table");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(refreshButton);


        String[] cols = { "ID", "Course", "Instr ID", "Semester", "Schedule", "Room", "Cap" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        sectionTable = new JTable(tableModel);
        sectionTable.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(sectionTable);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.add(formPanel, BorderLayout.CENTER);

        add(topContainer, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);


        addButton.addActionListener(e -> onAdd());
        updateButton.addActionListener(e -> onUpdate());
        deleteButton.addActionListener(e -> onDelete());
        clearButton.addActionListener(e -> clearForm());
        refreshButton.addActionListener(e -> loadSections());

        sectionTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                onTableRowSelected();
            }
        });


        loadSections();
    }



    private void loadSections() {
        tableModel.setRowCount(0);
        List<Section> list = adminService.getAllSections();
        if (list != null) {
            for (Section s : list) {
                tableModel.addRow(new Object[]{
                        s.getSectionId(),
                        s.getCourseId(),
                        s.getInstructorId(),
                        s.getSemester(),
                        s.getSchedule(),
                        s.getRoom(),
                        s.getCapacity()
                });
            }
        }
    }

    private void onAdd() {
        try {
            String courseId = courseIdField.getText().trim();
            int instructorId = Integer.parseInt(instructorIdField.getText().trim());
            String semester = semesterField.getText().trim();
            String schedule = scheduleField.getText().trim();
            String room = roomField.getText().trim();
            int capacity = (Integer) capacitySpinner.getValue();

            if (courseId.isEmpty() || semester.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Course ID and Semester are required.");
                return;
            }


            Section s = new Section(0, courseId, instructorId, semester, schedule, room, capacity);

            boolean ok = adminService.addSection(s);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Section added successfully!");
                loadSections();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add section. Check Course/Instructor IDs.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Instructor ID must be a number.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void onUpdate() {
        try {
            String idStr = sectionIdField.getText().trim();
            if (idStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select a section from the table to update.");
                return;
            }
            int sectionId = Integer.parseInt(idStr);
            String courseId = courseIdField.getText().trim();
            int instructorId = Integer.parseInt(instructorIdField.getText().trim());
            String semester = semesterField.getText().trim();
            String schedule = scheduleField.getText().trim();
            String room = roomField.getText().trim();
            int capacity = (Integer) capacitySpinner.getValue();

            Section s = new Section(sectionId, courseId, instructorId, semester, schedule, room, capacity);

            boolean ok = adminService.updateSection(s);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Section updated successfully!");
                loadSections();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Update failed.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void onDelete() {
        String idStr = sectionIdField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a section to delete.");
            return;
        }
        int sectionId = Integer.parseInt(idStr);

        int confirm = JOptionPane.showConfirmDialog(this, "Delete Section " + sectionId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean ok = adminService.deleteSection(sectionId);
            if (ok) {
                JOptionPane.showMessageDialog(this, "Deleted.");
                loadSections();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Delete failed.");
            }
        }
    }

    private void onTableRowSelected() {
        int row = sectionTable.getSelectedRow();
        if (row < 0) return;

        sectionIdField.setText(tableModel.getValueAt(row, 0).toString());
        courseIdField.setText(tableModel.getValueAt(row, 1).toString());
        instructorIdField.setText(tableModel.getValueAt(row, 2).toString());
        semesterField.setText(tableModel.getValueAt(row, 3).toString());
        scheduleField.setText(tableModel.getValueAt(row, 4).toString());
        roomField.setText(tableModel.getValueAt(row, 5).toString());
        capacitySpinner.setValue(tableModel.getValueAt(row, 6));
    }

    private void clearForm() {
        sectionIdField.setText("");
        courseIdField.setText("");
        instructorIdField.setText("");
        semesterField.setText("Fall 2025");
        scheduleField.setText("");
        roomField.setText("");
        capacitySpinner.setValue(30);
        sectionTable.clearSelection();
    }
}