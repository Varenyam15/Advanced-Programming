package edu.univ.erp.ui.admin;

import edu.univ.erp.api.admin.AdminCourseAPI;
import edu.univ.erp.domain.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;


public class CourseManagementPanel extends JPanel {

    private final AdminCourseAPI adminCourseAPI;

    private final JTable courseTable;
    private final DefaultTableModel tableModel;

    private final JTextField courseIdField;
    private final JTextField titleField;
    private final JTextField departmentField;
    private final JSpinner creditsSpinner;

    private final JButton addButton;
    private final JButton updateButton;
    private final JButton deleteButton;
    private final JButton clearButton;
    private final JButton refreshButton;

    public CourseManagementPanel() {
        this.adminCourseAPI = new AdminCourseAPI();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));




        JLabel header = new JLabel("Course Management", SwingConstants.CENTER);
        header.setFont(header.getFont().deriveFont(Font.BOLD, 18f));
        add(header, BorderLayout.NORTH);




        String[] columns = { "Course ID", "Title", "Department", "Credits" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        courseTable = new JTable(tableModel);
        courseTable.setAutoCreateRowSorter(true);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        courseTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                onTableRowSelected();
            }
        });

        JScrollPane tableScroll = new JScrollPane(courseTable);
        add(tableScroll, BorderLayout.CENTER);




        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Course Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel idLabel = new JLabel("Course ID:");
        JLabel titleLabel = new JLabel("Title:");
        JLabel deptLabel = new JLabel("Department:");
        JLabel creditsLabel = new JLabel("Credits:");

        courseIdField = new JTextField(15);
        titleField = new JTextField(15);
        departmentField = new JTextField(15);
        creditsSpinner = new JSpinner(new SpinnerNumberModel(3, 1, 30, 1));

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(idLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(courseIdField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(titleLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(titleField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(deptLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(departmentField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(creditsLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(creditsSpinner, gbc);




        JPanel buttonPanel = new JPanel(new GridLayout(1, 5, 5, 5));
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");
        refreshButton = new JButton("Refresh");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(refreshButton);

        gbc.gridx = 0; gbc.gridy = ++row;
        gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.EAST);




        addButton.addActionListener(e -> onAddCourse());
        updateButton.addActionListener(e -> onUpdateCourse());
        deleteButton.addActionListener(e -> onDeleteCourse());
        clearButton.addActionListener(e -> clearForm());
        refreshButton.addActionListener(e -> loadCourses());


        loadCourses();
    }





    private void loadCourses() {
        tableModel.setRowCount(0);

        List<Course> courses = adminCourseAPI.getAllCourses();
        if (courses == null) return;

        for (Course c : courses) {
            tableModel.addRow(new Object[] {
                    c.getCourseId(),
                    c.getCourseName(),
                    c.getDepartment(),
                    c.getCredits()
            });
        }
    }

    private void onAddCourse() {
        String courseId = courseIdField.getText().trim();
        String title = titleField.getText().trim();
        String dept = departmentField.getText().trim();
        int credits = (int) creditsSpinner.getValue();

        if (courseId.isEmpty() || title.isEmpty() || dept.isEmpty()) {
            showMessage("Please fill all fields.", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean ok = adminCourseAPI.createCourse(courseId, title, dept, credits);
        if (!ok) {
            showMessage("Failed to create course. It may already exist.", JOptionPane.ERROR_MESSAGE);
        } else {
            showMessage("Course created successfully.", JOptionPane.INFORMATION_MESSAGE);
            loadCourses();
            clearForm();
        }
    }

    private void onUpdateCourse() {
        String courseId = courseIdField.getText().trim();
        if (courseId.isEmpty()) {
            showMessage("Please select a course to update.", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String title = titleField.getText().trim();
        String dept = departmentField.getText().trim();
        int credits = (int) creditsSpinner.getValue();

        boolean ok = adminCourseAPI.updateCourse(courseId, title, dept, credits);
        if (!ok) {
            showMessage("Failed to update course.", JOptionPane.ERROR_MESSAGE);
        } else {
            showMessage("Course updated successfully.", JOptionPane.INFORMATION_MESSAGE);
            loadCourses();
        }
    }

    private void onDeleteCourse() {
        String courseId = courseIdField.getText().trim();
        if (courseId.isEmpty()) {
            showMessage("Please select a course to delete.", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete course " + courseId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        boolean ok = adminCourseAPI.deleteCourse(courseId);
        if (!ok) {
            showMessage("Failed to delete course.", JOptionPane.ERROR_MESSAGE);
        } else {
            showMessage("Course deleted successfully.", JOptionPane.INFORMATION_MESSAGE);
            loadCourses();
            clearForm();
        }
    }

    private void onTableRowSelected() {
        int row = courseTable.getSelectedRow();
        if (row < 0) return;

        String courseId = (String) tableModel.getValueAt(row, 0);
        String title = (String) tableModel.getValueAt(row, 1);
        String dept = (String) tableModel.getValueAt(row, 2);
        int credits = (int) tableModel.getValueAt(row, 3);

        courseIdField.setText(courseId);
        titleField.setText(title);
        departmentField.setText(dept);
        creditsSpinner.setValue(credits);
    }

    private void clearForm() {
        courseIdField.setText("");
        titleField.setText("");
        departmentField.setText("");
        creditsSpinner.setValue(3);
        courseTable.clearSelection();
    }

    private void showMessage(String msg, int type) {
        JOptionPane.showMessageDialog(this, msg, "Course Management", type);
    }




    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Course Management (Test)");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 400);
            frame.setLocationRelativeTo(null);

            frame.setContentPane(new CourseManagementPanel());
            frame.setVisible(true);
        });
    }
}
