package edu.univ.erp.util;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggerUtil {

    public static Logger getLogger(Class<?> clazz) {
        return Logger.getLogger(clazz.getName());
    }

    public static void info(Class<?> clazz, String message) {
        Logger logger = getLogger(clazz);
        logger.log(Level.INFO, message);
    }

    public static void warn(Class<?> clazz, String message) {
        Logger logger = getLogger(clazz);
        logger.log(Level.WARNING, message);
    }

    public static void error(Class<?> clazz, String message) {
        Logger logger = getLogger(clazz);
        logger.log(Level.SEVERE, message);
    }

    public static void error(Class<?> clazz, String message, Throwable t) {
        Logger logger = getLogger(clazz);
        logger.log(Level.SEVERE, message, t);
    }
}
