package edu.univ.erp.auth;

import edu.univ.erp.auth.model.AuthUser;


public class UserSession {

    private static AuthUser currentUser;





    public static void startSession(AuthUser user) {
        currentUser = user;
    }

    public static void endSession() {
        currentUser = null;
    }





    public static AuthUser getCurrentUser() {
        return currentUser;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static String getRole() {
        if (currentUser == null) return null;
        return currentUser.getRole();
    }

    public static String getUsername() {
        if (currentUser == null) return null;
        return currentUser.getUsername();
    }

    public static int getUserId() {
        if (currentUser == null) return -1;
        return currentUser.getUserId();
    }
}
