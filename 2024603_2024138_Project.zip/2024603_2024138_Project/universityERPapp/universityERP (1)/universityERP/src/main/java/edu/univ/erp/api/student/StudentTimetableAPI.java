package edu.univ.erp.api.student;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.CatalogService;
import edu.univ.erp.service.StudentService;

import java.util.ArrayList;
import java.util.List;


public class StudentTimetableAPI {

    private final StudentService studentService;
    private final CatalogService catalogService;

    public StudentTimetableAPI() {
        this.studentService = new StudentService();
        this.catalogService = new CatalogService();
    }

    private void requireStudent() {
        if (!UserSession.isLoggedIn() || !"STUDENT".equals(UserSession.getRole())) {
            throw new SecurityException("Access denied: STUDENT role required.");
        }
    }

    public List<Section> getMyTimetable() {
        requireStudent();
        int studentId = UserSession.getUserId();
        List<Enrollment> enrollments = studentService.getMyEnrollments(studentId);

        List<Section> sections = new ArrayList<>();
        for (Enrollment e : enrollments) {
            Section s = catalogService.getSectionById(e.getSectionId());
            if (s != null) {
                sections.add(s);
            }
        }
        return sections;
    }
}

