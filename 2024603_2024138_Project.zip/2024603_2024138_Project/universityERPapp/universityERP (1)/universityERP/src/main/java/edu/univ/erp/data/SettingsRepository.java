package edu.univ.erp.data;

import edu.univ.erp.domain.Setting;

import java.sql.*;

public class SettingsRepository {

    private final Connection conn;

    public SettingsRepository() {
        this.conn = DatabaseConfig.getErpConnection();
        if (this.conn == null) {
            throw new IllegalStateException("ERP DB connection is null. Check DatabaseConfig.");
        }
        createTableIfNotExists();
    }

    public void createTableIfNotExists() {
        // MySQL Syntax
        String sql = """
            CREATE TABLE IF NOT EXISTS settings (
              setting_key VARCHAR(100) PRIMARY KEY,
              setting_value VARCHAR(255)
            );
            """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.err.println("Error creating settings table: " + e.getMessage());
        }
    }

    public boolean saveOrUpdateSetting(Setting setting) {
        // MySQL Syntax for "Upsert" (Insert or Update)
        String sql = """
            INSERT INTO settings(setting_key, setting_value)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, setting.getSettingKey());
            ps.setString(2, setting.getSettingValue());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error saving setting: " + e.getMessage());
            return false;
        }
    }

    // --- THIS IS THE MISSING METHOD YOU NEED ---
    public Setting getSetting(String key) {
        String sql = "SELECT * FROM settings WHERE setting_key = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, key);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Setting(
                            rs.getString("setting_key"),
                            rs.getString("setting_value")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching setting: " + e.getMessage());
        }
        return null; // Return null if not found
    }
}