package edu.univ.erp.api.catalog;

import edu.univ.erp.domain.Course;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.CatalogService;

import java.util.List;


public class CatalogAPI {

    private final CatalogService catalogService;

    public CatalogAPI() {
        this.catalogService = new CatalogService();
    }

    public List<Course> getAllCourses() {
        return catalogService.getAllCourses();
    }

    public Course getCourseById(String courseId) {
        return catalogService.getCourseById(courseId);
    }

    public List<Section> getSectionsForCourse(String courseId) {
        return catalogService.getSectionsForCourse(courseId);
    }
}


