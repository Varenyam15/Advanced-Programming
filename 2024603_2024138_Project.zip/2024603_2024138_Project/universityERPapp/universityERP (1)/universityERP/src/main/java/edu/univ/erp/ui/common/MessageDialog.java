package edu.univ.erp.ui.common;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MessageDialog extends JDialog {

    private final JLabel messageLabel;
    private final JButton okButton;

    public MessageDialog(Frame parent, String title, String message) {
        super(parent, title, true);

        setSize(350, 150);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        messageLabel = new JLabel(message, SwingConstants.CENTER);
        add(messageLabel, BorderLayout.CENTER);

        okButton = new JButton("OK");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(okButton);
        add(buttonPanel, BorderLayout.SOUTH);

        okButton.addActionListener(this::closeDialog);
    }

    private void closeDialog(ActionEvent e) {
        dispose();
    }

    public static void showMessage(Frame parent, String title, String message) {
        MessageDialog dialog = new MessageDialog(parent, title, message);
        dialog.setVisible(true);
    }
}
