package edu.univ.erp.service;

import edu.univ.erp.data.GradeRepository;
import edu.univ.erp.data.EnrollmentRepository;
import edu.univ.erp.domain.Grade;
import edu.univ.erp.domain.Enrollment;

import java.util.List;


public class GradeService {

    private final GradeRepository gradeRepo;
    private final EnrollmentRepository enrollmentRepo;




    public GradeService() {
        this.gradeRepo = new GradeRepository();
        this.enrollmentRepo = new EnrollmentRepository();
    }






    public boolean assignGrade(int enrollmentId, String letterGrade, double gradePoints) {
        Grade existing = gradeRepo.getGradeByEnrollmentId(enrollmentId);

        if (existing == null) {

            Grade newGrade = new Grade(0, enrollmentId, letterGrade, gradePoints);
            return gradeRepo.insertGrade(newGrade);
        } else {

            existing.setLetterGrade(letterGrade);
            existing.setGradePoints(gradePoints);
            return gradeRepo.updateGrade(existing);
        }
    }


    public boolean updateGrade(Grade grade) {
        return gradeRepo.updateGrade(grade);
    }





    public Grade getGradeByEnrollment(int enrollmentId) {
        return gradeRepo.getGradeByEnrollmentId(enrollmentId);
    }

    public Grade getGradeById(int gradeId) {
        return gradeRepo.getGradeById(gradeId);
    }

    public List<Grade> getAllGrades() {
        return gradeRepo.getAllGrades();
    }






    public List<Grade> getGradesForStudent(int studentId) {
        return enrollmentRepo.getEnrollmentsByStudent(studentId)
                .stream()
                .map(enrollment -> gradeRepo.getGradeByEnrollmentId(enrollment.getEnrollmentId()))
                .filter(g -> g != null)
                .toList();
    }


    public double calculateGPA(int studentId) {
        List<Grade> grades = getGradesForStudent(studentId);

        if (grades.isEmpty()) return 0.0;

        double total = grades.stream()
                .mapToDouble(Grade::getGradePoints)
                .sum();

        return total / grades.size();
    }
}
