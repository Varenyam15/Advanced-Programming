package edu.univ.erp.ui.student;

import edu.univ.erp.api.auth.LoginAPI;
import edu.univ.erp.auth.UserSession;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class StudentDashboard extends JFrame {

    private final LoginAPI loginAPI;
    private final JLabel welcomeLabel;
    private final JButton catalogButton;
    private final JButton registrationButton;
    private final JButton timetableButton;
    private final JButton gradesButton;
    private final JButton logoutButton;

    public StudentDashboard() {
        super("University ERP - Student Dashboard");

        this.loginAPI = new LoginAPI();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        if (new edu.univ.erp.service.MaintenanceService().isMaintenanceMode()) {
            JLabel banner = new JLabel("⚠️ SYSTEM IN MAINTENANCE MODE - READ ONLY ⚠️", SwingConstants.CENTER);
            banner.setOpaque(true);
            banner.setBackground(Color.RED);
            banner.setForeground(Color.WHITE);
            banner.setFont(new Font("SansSerif", Font.BOLD, 14));
            add(banner, BorderLayout.NORTH);
        }

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        String username = UserSession.getUsername();
        welcomeLabel = new JLabel("Welcome, Student " + (username != null ? username : ""), SwingConstants.CENTER);
        welcomeLabel.setFont(welcomeLabel.getFont().deriveFont(Font.BOLD, 18f));
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        catalogButton = new JButton("Course Catalog");
        registrationButton = new JButton("Registration");
        timetableButton = new JButton("Timetable");
        gradesButton = new JButton("Grades");
        logoutButton = new JButton("Logout");

        centerPanel.add(catalogButton);
        centerPanel.add(registrationButton);
        centerPanel.add(timetableButton);
        centerPanel.add(gradesButton);
        centerPanel.add(new JLabel());
        centerPanel.add(logoutButton);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JLabel statusLabel = new JLabel("Student mode", SwingConstants.CENTER);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        catalogButton.addActionListener(this::onCatalog);
        registrationButton.addActionListener(this::onRegistration);
        timetableButton.addActionListener(this::onTimetable);
        gradesButton.addActionListener(this::onGrades);
        logoutButton.addActionListener(this::onLogout);

        setContentPane(mainPanel);

        if (!UserSession.isLoggedIn() || !"STUDENT".equals(UserSession.getRole())) {
            JOptionPane.showMessageDialog(
                    this,
                    "Access denied: STUDENT role required.",
                    "Unauthorized",
                    JOptionPane.ERROR_MESSAGE
            );
            dispose();
        }
    }

    private void onCatalog(ActionEvent e) {
        JFrame frame = new JFrame("Course Catalog");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(this);
        frame.setContentPane(new CourseCatalogPanel());
        frame.setVisible(true);
    }

    private void onRegistration(ActionEvent e) {
        JFrame frame = new JFrame("Registration");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(this);
        frame.setContentPane(new RegistrationPanel());
        frame.setVisible(true);
    }

    private void onTimetable(ActionEvent e) {
        JFrame frame = new JFrame("Timetable");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(this);
        frame.setContentPane(new TimetablePanel());
        frame.setVisible(true);
    }

    private void onGrades(ActionEvent e) {
        JFrame frame = new JFrame("Grades");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(900, 500);
        frame.setLocationRelativeTo(this);
        frame.setContentPane(new GradesPanel());
        frame.setVisible(true);
    }

    private void onLogout(ActionEvent e) {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION
        );
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }
        loginAPI.logout();
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentDashboard dashboard = new StudentDashboard();
            dashboard.setVisible(true);
        });
    }
}
