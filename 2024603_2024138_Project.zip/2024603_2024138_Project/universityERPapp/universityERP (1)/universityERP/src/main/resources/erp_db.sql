
CREATE DATABASE IF NOT EXISTS erp_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE erp_db;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS grades;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS sections;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS instructors;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS settings;

SET FOREIGN_KEY_CHECKS = 1;

-- SETTINGS
CREATE TABLE settings (
    setting_key   VARCHAR(100) PRIMARY KEY,
    setting_value VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- STUDENTS
CREATE TABLE students (
    student_id  INT AUTO_INCREMENT PRIMARY KEY,
    first_name  VARCHAR(100) NOT NULL,
    last_name   VARCHAR(100) NOT NULL,
    email       VARCHAR(200) NOT NULL UNIQUE,
    major       VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- INSTRUCTORS
CREATE TABLE instructors (
    instructor_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name    VARCHAR(100) NOT NULL,
    last_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(200) NOT NULL UNIQUE,
    department    VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- COURSES
CREATE TABLE courses (
    course_id   VARCHAR(20) PRIMARY KEY,
    course_name VARCHAR(200) NOT NULL,
    department  VARCHAR(100),
    credits     INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SECTIONS
CREATE TABLE sections (
    section_id    INT AUTO_INCREMENT PRIMARY KEY,
    course_id     VARCHAR(20) NOT NULL,
    instructor_id INT NOT NULL,
    semester      VARCHAR(50) NOT NULL,
    schedule      VARCHAR(100),
    room          VARCHAR(50),
    capacity      INT NOT NULL,
    CONSTRAINT fk_sections_course
        FOREIGN KEY (course_id) REFERENCES courses(course_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_sections_instructor
        FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ENROLLMENTS
CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT NOT NULL,
    section_id    INT NOT NULL,
    status        VARCHAR(20) DEFAULT 'ENROLLED',
    CONSTRAINT fk_enrollments_student
        FOREIGN KEY (student_id) REFERENCES students(student_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_enrollments_section
        FOREIGN KEY (section_id) REFERENCES sections(section_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- GRADES
CREATE TABLE grades (
    grade_id      INT AUTO_INCREMENT PRIMARY KEY,
    enrollment_id INT NOT NULL,
    letter_grade  VARCHAR(2) NOT NULL,
    grade_points  DECIMAL(4,2) NOT NULL,
    CONSTRAINT fk_grades_enrollment
        FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional seed data for quick testing

INSERT INTO students (first_name, last_name, email, major) VALUES
('Test', 'Student', 'stud1@example.com', 'Computer Science');

INSERT INTO instructors (first_name, last_name, email, department) VALUES
('Test', 'Instructor', 'inst1@example.com', 'Computer Science');

INSERT INTO courses (course_id, course_name, department, credits) VALUES
('CS101', 'Intro to Computer Science', 'CSE', 4);

INSERT INTO sections (course_id, instructor_id, semester, schedule, room, capacity) VALUES
('CS101', 1, 'Fall 2025', 'Mon 10-12', 'R101', 30);

-- Default settings
INSERT INTO settings (setting_key, setting_value) VALUES
('CURRENT_SEMESTER', 'Fall 2025'),
('REGISTRATION_STATUS', 'OPEN');
