
CREATE DATABASE IF NOT EXISTS auth_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE auth_db;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS auth_users;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE auth_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('ADMIN', 'INSTRUCTOR', 'STUDENT') NOT NULL,
    salt VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO auth_users (username, password_hash, role, salt) VALUES
('admin', 'admin123', 'ADMIN',      'dummySalt'),
('inst1', 'inst123',  'INSTRUCTOR', 'dummySalt'),
('stud1', 'stud123',  'STUDENT',    'dummySalt');
